# 01_PHASE1_METHOD_NOTES_RECURSIVE_MECHANICS

The method treats each pass as dual-output production:
- writing artifact
- governance artifact

Recursive mechanics used in this rebuild:
- archive-bounded ingestion
- evidence-status tagging
- contradiction-aware merge decisions
- protocolized promotion criteria

RECURSO drafts embedded in RECURSUS are retained as recursive evidence, not discarded as noise.
