# 01_PHASE1_FUNCTION_MAP_PHASE_SLICE

| path | revision_status | action | evidence_status |
|---|---|---|---|
| `2017 - Charging Objects Ritual, Artistic Practice, and the Crisis of Legitimacy.docx` | revised | PRESERVE_AND_LIGHTLY_CLEAN | source_bearing_artifact |
| `THE VIOLET GEM (1).odt` | revised | PRESERVE_AS_IS | source_bearing_artifact |
| `Alambic.odt` | revised | PRESERVE_AS_IS | source_bearing_artifact |
| `2004 - Title The Sealed Card Protocol Mediated Legitimacy, Charging, and Governance at the Seam.docx` | revised | PRESERVE_AND_LIGHTLY_CLEAN | source_bearing_artifact |
| `DELIVEREX.txt` | original | PRESERVE_AS_IS | supporting_archive_artifact |
| `EXPLAIN PHASE 1 PASS.txt` | cleaned_derivative | MERGE_WITH_RELATED_FILE | supporting_archive_artifact |
| `Agathav4.1.docx` | revised | PRESERVE_AND_LIGHTLY_CLEAN | source_bearing_artifact |
| `PEER_REVIEW_READY_MANUSCRIPT_EXPANDED_300.md` | expanded | PRESERVE_AND_LIGHTLY_CLEAN | source_bearing_artifact |
| `ai-anxiety-recursive-governance-ai-society-aligned-2026-03-11.md` | original | MERGE_WITH_RELATED_FILE | source_bearing_artifact |
| `RDAIG_method_editorial_consolidation_2026-03-14.md` | near_final | PRESERVE_AS_IS | source_bearing_artifact |
| `RDAIG_governance_test_2026-03-14.md` | near_final | PRESERVE_AS_IS | source_bearing_artifact |
| `AI GOV CONSTITUTION.pdf` | revised | PRESERVE_AS_IS | source_bearing_artifact |
| `index.html` | original | PRESERVE_AS_IS | supporting_archive_artifact |
