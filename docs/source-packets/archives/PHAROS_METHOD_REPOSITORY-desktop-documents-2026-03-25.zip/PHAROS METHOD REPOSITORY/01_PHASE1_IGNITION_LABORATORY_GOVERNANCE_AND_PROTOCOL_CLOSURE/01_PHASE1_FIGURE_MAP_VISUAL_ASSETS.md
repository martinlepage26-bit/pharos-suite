# 01_PHASE1_FIGURE_MAP_VISUAL_ASSETS

## Visual/Map Artifacts
- `governance_storyboard.html` (storyboard rendering)
- `rdaig_explainer.html` (method explainer surface)
- `martin_lepage_governance_tree.html` (governance tree)
- `skill_ecosystem_tree.html` (distribution map)

These files are treated as figure/support artifacts, not as sole authority for governance claims.
