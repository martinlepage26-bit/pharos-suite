# 01_PHASE1_CHRONOLOGY_MAP_PHASE_SLICE

| idx | modified_utc | path |
|---:|---|---|
| 1 | 2026-01-19T06:05:42.021564+00:00 | `2017 - Charging Objects Ritual, Artistic Practice, and the Crisis of Legitimacy.docx` |
| 4 | 2026-03-01T01:44:51.809030+00:00 | `THE VIOLET GEM (1).odt` |
| 5 | 2026-03-01T02:18:14.362173+00:00 | `Alambic.odt` |
| 6 | 2026-03-07T09:03:34.703046+00:00 | `2004 - Title The Sealed Card Protocol Mediated Legitimacy, Charging, and Governance at the Seam.docx` |
| 23 | 2026-03-09T17:23:34.496291+00:00 | `DELIVEREX.txt` |
| 24 | 2026-03-09T17:24:22.323395+00:00 | `EXPLAIN PHASE 1 PASS.txt` |
| 36 | 2026-03-10T06:01:41.713421+00:00 | `Agathav4.1.docx` |
| 41 | 2026-03-10T07:32:15.071787+00:00 | `PEER_REVIEW_READY_MANUSCRIPT_EXPANDED_300.md` |
| 50 | 2026-03-11T17:32:59.328363+00:00 | `ai-anxiety-recursive-governance-ai-society-aligned-2026-03-11.md` |
| 90 | 2026-03-14T08:37:42.070017+00:00 | `RDAIG_method_editorial_consolidation_2026-03-14.md` |
| 93 | 2026-03-14T10:00:56.391647+00:00 | `RDAIG_governance_test_2026-03-14.md` |
| 100 | 2026-03-14T11:43:19+00:00 | `AI GOV CONSTITUTION.pdf` |
| 112 | 2026-03-23T01:54:16.746005+00:00 | `index.html` |
