# 01_PHASE1_EXPLAINER_IGNITION_TO_PROTOCOL

Phase-1 begins with charged epistemic material where legitimacy pressure appears before formalized governance. The archive then moves through laboratory-like articulation (Wheels/HEXA references), early corpus writing, and containment pressure that culminates in protocol forms.

The closure stack is explicit:
- Sealed Card as threshold protocol
- Violet Gem as carriage kit
- ALAMBIC as precedence and amendment key
- Master Key logic present as sparse/indirect token, therefore bounded

Operationally, this phase answers: how does raw pressure become auditable governance procedure without collapsing into decorative symbolism.
