# 01_PHASE1_CONTROL_LOGIC_GATES_AND_CONSTRAINTS

## Control Gates (Phase-1)
1. Scope clamp gate: name system, deployment site, consequence domain, and decision timebox.
2. Role-binding gate: owner, risk/compliance, implementation, witness.
3. Evidence gate: distinguish source-bearing artifact from generated derivative.
4. Protocol precedence gate: Oath -> Constitution -> Core Protocols -> System Specs -> Field Kit -> Labs/Interfaces.
5. Closure gate: Sealed Card threshold must be satisfied before promotion.

## Drift Controls
- Duplicate clusters are de-ranked to prevent authority inflation.
- Superseded but important files remain retained for lineage auditability.
