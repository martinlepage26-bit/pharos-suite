# 90_CONSOLIDATED_SKILL_ARCHITECT_AND_SKILL_DISTRIBUTION_CROSSWALK

- distributed skill units (`SKILL.md`) mapped: `14`
- canonical meta-governance file: `02_GOVERNANCE_REVISION_SKILL_DISTRIBUTION_AND_META_GOVERNANCE/skill-architect.md`
- crosswalk rule: distributed skill execution inherits meta-governance constraints before forge/runtime execution

| layer | token | control object |
|---|---|---|
| distribution | `SKILL_DISTRIBUTION` | standalone `SKILL.md` units |
| meta-governance | `SKILL_ARCHITECT` | `skill-architect.md` |
| forge/build | `HEPHAISTOS_WSL` | shared WSL-mediated pipeline |
