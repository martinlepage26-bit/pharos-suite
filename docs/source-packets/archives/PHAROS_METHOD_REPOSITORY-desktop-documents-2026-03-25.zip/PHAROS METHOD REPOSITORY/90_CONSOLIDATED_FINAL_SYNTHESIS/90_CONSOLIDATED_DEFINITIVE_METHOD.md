# 90_CONSOLIDATED_DEFINITIVE_METHOD

Definitive method in this rebuild:
1. ingest full archive
2. classify each file across chronology/function/method/revision/recursive role
3. rank authority and resolve overlap clusters
4. preserve strong prose and lineage
5. improve weak artifacts without flattening stronger texts
6. generate missing phase structure and controls
7. produce bounded synthesis with explicit claim limits
