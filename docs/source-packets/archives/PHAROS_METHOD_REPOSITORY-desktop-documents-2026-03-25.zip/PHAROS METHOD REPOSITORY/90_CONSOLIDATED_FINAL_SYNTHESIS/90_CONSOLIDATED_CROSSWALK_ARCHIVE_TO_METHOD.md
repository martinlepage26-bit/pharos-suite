# 90_CONSOLIDATED_CROSSWALK_ARCHIVE_TO_METHOD

Archive object classes are mapped to method positions through:
- `DATA/MANIFESTS/00_ARCHIVE_METADATA_MANIFEST.csv`
- `DATA/MANIFESTS/00_METHOD_ROLE_CLASSIFICATION_MAP.json`
- `DATA/CONTROLS/00_CONTROL_PHASE_TEST_RESULTS.md`

Crosswalk principle:
- source-bearing artifacts anchor method claims
- derivatives remain lineage evidence but are de-ranked
- crosswalk claims stay bounded where direct term-level evidence is absent and interpretation is carried by governance notes
