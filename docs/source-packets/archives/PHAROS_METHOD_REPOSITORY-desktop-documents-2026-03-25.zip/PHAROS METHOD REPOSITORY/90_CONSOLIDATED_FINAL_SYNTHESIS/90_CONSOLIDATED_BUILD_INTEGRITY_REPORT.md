# 90_CONSOLIDATED_BUILD_INTEGRITY_REPORT

- build_root: `/home/cerebrhoe/HEPHAISTOS_BUILD/MASTERxMASTERxMASTER_REBUILT`
- source_archive_path: `/mnt/c/Users/softinfo/Documents/MASTER PACK/MASTERxMASTERxMASTER`
- run_id: `2026-03-24T14:33:19.048475+00:00`
- config_source: `DATA/LOGS/00_build_context.json`
- config_fingerprint: `f5fa7fb1b4faae5dcb1238b1913d3888e8588877b6bcb708055398bc1a37365a`
- root_coherence_pass: `True`
- provenance_propagation_pass: `True`
- extracted_text_collision_safe_pass: `True`
- governance_revision_explicit_mapping_pass: `True`
- governance_revision_tokens_pass: `True`
- skill_architect_naming_pass: `True`
- canonical_status_schema: `blocked_not_ready, failed, incomplete, needs_revision_before_promotion, ready_full, ready_with_bounded_gaps`
- canonical_status_pass: `True`
- derived_metrics_pass: `True`
- clean_rebuild_requested: `True`
- clean_rebuild_succeeded: `True`
- overall_status: `ready_full`
- hepaistos_compliance: `pass`

## Runtime Coherence
- required_runtime_log: `00_ingest_runtime_config.json`
- required_runtime_log: `01_classify_runtime_config.json`
- required_runtime_log: `02_phase_tests_runtime_config.json`
- required_runtime_log: `03_generate_docs_runtime_config.json`
- found_runtime_log: `00_ingest_runtime_config.json`
- found_runtime_log: `01_classify_runtime_config.json`
- found_runtime_log: `02_phase_tests_runtime_config.json`
- found_runtime_log: `03_generate_docs_runtime_config.json`

## Remaining Bounded Items
- none
