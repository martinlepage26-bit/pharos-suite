# 90_CONSOLIDATED_ARCHITECTURE_TOKENS_AND_METHOD_READABILITY

## Canonical Token Schema
| token | label | full_name | stage | function | upstream_dependency | downstream_consequence | archive_evidence_basis | confidence |
|---|---|---|---|---|---|---|---|---|
| AIGOV1 | First Governance Containment | AI Governance Version 1 Containment Layer | 1_first_governance_containment | admissibility, voice discipline, evidence handling, workflow containment | none | AIGOV2, VOICEOP2 | `AI GOV CONSTITUTION.pdf`; `RDAIG_governance_test_2026-03-14.md`; `RDAIG_method_editorial_consolidation_2026-03-14.md` | medium_bounded_equivalence |
| VOICEOP1 | First Voice Operator Layer | Voice Operator Version 1 | 1_first_governance_containment | operator voice discipline and review containment | AIGOV1 | VOICEOP2 | `AI GOV CONSTITUTION.pdf`; `02_GOVREV_OPERATOR_SET_V1_REVISION_PROTOCOL.md` | medium_bounded_equivalence |
| AIGOV2 | Recursive Governance Intensification | AI Governance Version 2 | 2_governance_revision | recursive intensification of containment and distribution readiness | AIGOV1, VOICEOP1 | SKILL_DISTRIBUTION | `02_GOVREV_NOTE_AIGOV2_VOICEOP2_EQUIVALENCE.md`; `02_GOVREV_AIGOV2_VOICEOP2_CLASSIFICATION.md` | medium_explicit_revision_tokenized |
| VOICEOP2 | Revised Voice Operator Layer | Voice Operator Version 2 | 2_governance_revision | recursive governance revision routed through voice discipline updates | VOICEOP1, AIGOV2 | SKILL_DISTRIBUTION | `02_GOVREV_NOTE_AIGOV2_VOICEOP2_EQUIVALENCE.md`; `02_GOVREV_OPERATOR_SET_V1_REVISION_PROTOCOL.md` | medium_explicit_revision_tokenized |
| SKILL_DISTRIBUTION | Distributed Skill Layer | Standalone skill.md distribution layer | 3_skill_distribution | portable modular governance execution units | AIGOV2, VOICEOP2 | SKILL_ARCHITECT | `brand-identity-system/SKILL.md`; `fully-rounded-power-analyst/SKILL.md`; `humanize/SKILL.md`; `novelist/SKILL.md`; `peer-reviewed-paper-writer/SKILL.md`; `publisher/SKILL.md`; `qualitative/SKILL.md`; `recursive-governance-method/SKILL.md`; `red-team/SKILL.md`; `skill-pairing/SKILL.md` | high |
| SKILL_ARCHITECT | Meta-Governance Skill Architecture | skill-architect.md canonical meta-governance layer | 4_skill_architect_meta_governance | govern skill routing, inheritance, constraints, and interoperability | SKILL_DISTRIBUTION | HEPHAISTOS_WSL | `skill-architect.md`; `02_GOVERNANCE_REVISION_SKILL_ARCHITECT_META_GOVERNANCE.md` | high |
| HEPHAISTOS_WSL | Shared Forge Layer | Hephaistos shared WSL-mediated build substrate | 5_hephaistos_forge | make recursively revised governance executable through shared build governance | SKILL_ARCHITECT | CODEX_RUNTIME, CLAUDE_RUNTIME | `02_GOVREV_HEPHAISTOS_WSL_IMPLEMENTATION_MAP.md`; `heppaper.txt`; `After reboot checklist.txt` | high |
| CODEX_RUNTIME | Codex Runtime | Codex implementation under Hephaistos governance | 6_runtime_environments | agentic execution runtime bound to shared forge governance | HEPHAISTOS_WSL | none | `02_GOVREV_CODEX_CLAUDE_CROSS_IMPLEMENTATION_NOTE.md`; `90_CONSOLIDATED_HEPHAISTOS_WSL_CODEX_CLAUDE_IMPLEMENTATION_MAP.md` | high |
| CLAUDE_RUNTIME | Claude Runtime | Claude implementation under Hephaistos governance | 6_runtime_environments | agentic execution runtime bound to shared forge governance | HEPHAISTOS_WSL | none | `02_GOVREV_CODEX_CLAUDE_CROSS_IMPLEMENTATION_NOTE.md`; `90_CONSOLIDATED_HEPHAISTOS_WSL_CODEX_CLAUDE_IMPLEMENTATION_MAP.md` | high |

## Canonical Lineage
| from | to | relation |
|---|---|---|
| AIGOV1, VOICEOP1 | AIGOV2, VOICEOP2 | recursive_intensification |
| AIGOV2, VOICEOP2 | SKILL_DISTRIBUTION | distribution |
| SKILL_DISTRIBUTION | SKILL_ARCHITECT | meta_governance_binding |
| SKILL_ARCHITECT | HEPHAISTOS_WSL | forge_activation |
| HEPHAISTOS_WSL | CODEX_RUNTIME | runtime_binding |
| HEPHAISTOS_WSL | CLAUDE_RUNTIME | runtime_binding |

Method-readability claim:
- architecture stage mapping is explicit in both machine-readable and narrative forms.
