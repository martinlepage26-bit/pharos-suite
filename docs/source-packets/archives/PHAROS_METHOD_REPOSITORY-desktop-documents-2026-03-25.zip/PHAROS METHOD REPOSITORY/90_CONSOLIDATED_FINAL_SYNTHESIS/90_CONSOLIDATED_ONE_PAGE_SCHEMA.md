# 90_CONSOLIDATED_ONE_PAGE_SCHEMA

Source Archive -> Classification Manifests -> Authority Ranking -> Phase Packets (01/02/03/04) -> Consolidated Synthesis (90) -> Submission Package (99)

Control rails across all stages:
- evidence hierarchy
- overlap de-dup authority
- bounded claim boundary
- protocol closure before promotion
- governance-over-fabrication precedence
