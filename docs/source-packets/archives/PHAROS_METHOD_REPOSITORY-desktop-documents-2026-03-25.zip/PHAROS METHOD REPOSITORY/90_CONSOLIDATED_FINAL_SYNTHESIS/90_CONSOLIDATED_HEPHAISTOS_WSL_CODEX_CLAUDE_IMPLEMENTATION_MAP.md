# 90_CONSOLIDATED_HEPHAISTOS_WSL_CODEX_CLAUDE_IMPLEMENTATION_MAP

Shared forge model:
- `HEPHAISTOS_WSL` is the build/fabrication governance substrate.
- `CODEX_RUNTIME` and `CLAUDE_RUNTIME` are peer runtime implementations under shared forge governance.

Non-ambiguity rule:
- Hephaistos is not runtime-exclusive.
- Codex is not the forge.
- Claude is not the forge.
- both runtimes execute under forge constraints from `skill-architect.md`.
