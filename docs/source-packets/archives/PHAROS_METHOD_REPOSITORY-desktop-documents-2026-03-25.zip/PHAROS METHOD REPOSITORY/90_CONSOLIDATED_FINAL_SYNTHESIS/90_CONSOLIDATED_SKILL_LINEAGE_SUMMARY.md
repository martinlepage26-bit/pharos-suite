# 90_CONSOLIDATED_SKILL_LINEAGE_SUMMARY

Skill lineage is represented by modular `SKILL.md` files with associated references and operator configs.

Governance implication:
- distribution is strong
- canonical meta-governance object is `skill-architect.md`
- distributed skill execution is explicitly bound to shared forge governance
