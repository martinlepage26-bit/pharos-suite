#!/usr/bin/env python3
"""Compatibility wrapper forwarding to 02_build_keyword_matrix_and_phase_tests.py."""
import runpy
from pathlib import Path

runpy.run_path(str(Path(__file__).with_name("02_build_keyword_matrix_and_phase_tests.py")), run_name="__main__")
