#!/usr/bin/env python3
"""Compatibility wrapper forwarding to 04_validate_rebuild.py."""
import runpy
from pathlib import Path

runpy.run_path(str(Path(__file__).with_name("04_validate_rebuild.py")), run_name="__main__")
