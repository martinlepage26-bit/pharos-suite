#!/usr/bin/env python3
"""Compatibility wrapper forwarding to 01_classify_archive_and_scaffold.py."""
import runpy
from pathlib import Path

runpy.run_path(str(Path(__file__).with_name("01_classify_archive_and_scaffold.py")), run_name="__main__")
