#!/usr/bin/env python3
"""Compatibility wrapper for canonical shared config module."""
from pipeline_config_and_status_schema import *  # noqa: F401,F403
