#!/usr/bin/env python3
"""Ingest source archive into the Hephaistos rebuild root.

This stage is the canonical provenance anchor for downstream pipeline steps.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Tuple

from pipeline_config_and_status_schema import (
    EXTRACTED_TEXT_INDEX_PATH,
    add_common_args,
    make_extracted_text_identity,
    normalize_rel_path,
    resolve_context,
    write_build_context,
    write_json,
    write_stage_runtime_config,
)

TEXT_EXTS = {".txt", ".md", ".html", ".htm", ".yaml", ".yml", ".py", ".css", ".svg", ".json", ".csv"}
PARSABLE_EXTS = TEXT_EXTS | {".docx", ".odt", ".pdf"}

DATE_PATTERNS = [
    r"\b(20\d{2}-\d{2}-\d{2})\b",
    r"\b(20\d{2}/\d{2}/\d{2})\b",
    r"\b(\d{4})\b",
    r"\b((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\s+\d{1,2},\s+20\d{2})\b",
]

KEYWORDS = {
    "ignition": ["witch", "agatha all along", "charge", "charging"],
    "lab": ["hexa", "wheels of will", "laboratory"],
    "governance": ["aigov", "constitution", "voice operator", "governance"],
    "protocol": ["sealed card", "violet gem", "alambic", "master key", "protocol"],
    "topology": ["theseus", "auryn", "hopf", "limit does not exist", "non-convergent"],
    "skills": ["skill.md", "skill", "masterskill", "skill distribution"],
    "implementation": ["lotus", "echo", "scriptorium", "dr. sort", "compassai", "aurorai", "govern-ai", "pharos"],
    "operator": ["henry", "reviewer #2", "governess agatha"],
    "buffy": ["buffy", "hair as battle scar", "for her alone to wield"],
    "recurso": ["recurso", "recursus", "recursive"],
}


def sha256_file(path: Path) -> str:
    """Compute SHA256 for a file."""
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_text(path: Path) -> Tuple[str, str]:
    """Extract text from supported file types."""
    ext = path.suffix.lower()
    try:
        if ext in TEXT_EXTS:
            text = path.read_text(encoding="utf-8", errors="replace")
            return text, "ok"

        if ext == ".docx":
            try:
                import docx  # type: ignore

                d = docx.Document(str(path))
                text = "\n".join(p.text for p in d.paragraphs)
                return text, "ok"
            except Exception:
                pass
            out = subprocess.run(["python3", "-m", "docx2txt", str(path), "-"], capture_output=True, text=True)
            if out.returncode == 0:
                return out.stdout, "ok_docx2txt"
            return "", f"partial_docx_failed:{out.stderr[:120]}"

        if ext == ".odt":
            try:
                with zipfile.ZipFile(path, "r") as zf:
                    data = zf.read("content.xml")
                root = ET.fromstring(data)
                chunks = []
                for elem in root.iter():
                    if elem.text and elem.text.strip():
                        chunks.append(elem.text.strip())
                text = "\n".join(chunks)
                return text, "ok_zipxml"
            except Exception:
                out = subprocess.run(["strings", "-n", "6", str(path)], capture_output=True, text=True)
                if out.returncode == 0:
                    return out.stdout, "partial_strings"
                return "", "partial_odt_failed"

        if ext == ".pdf":
            try:
                from pypdf import PdfReader  # type: ignore

                reader = PdfReader(str(path))
                pages = []
                for page in reader.pages:
                    pages.append(page.extract_text() or "")
                return "\n\n".join(pages), "ok"
            except Exception:
                out = subprocess.run(["pdftotext", "-layout", str(path), "-"], capture_output=True, text=True)
                if out.returncode == 0:
                    return out.stdout, "ok_pdftotext"
                return "", "partial_pdf_failed"

        return "", "unparsed_binary"
    except Exception as e:
        return "", f"error:{type(e).__name__}:{e}"


def guess_function(path: Path, text_l: str) -> str:
    """Best-effort functional role classification at ingest time."""
    name = path.name.lower()
    rel = str(path).lower()
    if "skill" in name and path.suffix.lower() == ".md":
        return "skill_file"
    if "/agents/" in rel and path.suffix.lower() in {".yaml", ".yml"}:
        return "skill_agent_config"
    if "/references/" in rel:
        return "reference_note"
    if "/scripts/" in rel and path.suffix.lower() in {".py", ".sh", ".ps1"}:
        return "build_or_method_script"
    if path.suffix.lower() in {".docx", ".odt", ".pdf", ".md"}:
        if any(k in text_l for k in ["manuscript", "paper", "ai and society", "peer review"]):
            return "paper_or_manuscript"
        if any(k in text_l for k in ["constitution", "governance", "voice operator", "protocol"]):
            return "governance_or_protocol_document"
    if path.suffix.lower() in {".html"}:
        if "tree" in name or "storyboard" in name:
            return "map_or_visualization"
        return "web_surface_or_explainer"
    if path.suffix.lower() in {".txt", ".md"}:
        return "note_or_draft"
    return "other_artifact"


def guess_method_role(rel: str, text_l: str) -> str:
    """Best-effort method role guess for early indexing."""
    joined = f"{rel.lower()}\n{text_l[:5000]}"
    if any(k in joined for k in ["witch", "agatha all along", "charging"]):
        return "epistemic_ignition"
    if any(k in joined for k in ["hexa", "wheels of will", "laboratory"]):
        return "laboratory_formation"
    if any(k in joined for k in ["constitution", "voice operator", "aigov"]):
        return "governance_containment_or_revision"
    if any(k in joined for k in ["sealed card", "violet gem", "alambic", "master key"]):
        return "phase1_closure_protocol"
    if "skill" in rel.lower() or "masterskill" in joined:
        return "skill_distribution_or_meta_governance"
    if any(k in joined for k in ["hephaistos", "forge", "build", "wsl"]):
        return "hephaistos_forge_build_layer"
    if any(k in joined for k in ["lotus", "echo", "scriptorium", "dr. sort", "compassai", "aurorai", "pharos"]):
        return "implementation_surface"
    if any(k in joined for k in ["theseus", "auryn", "hopf", "limit does not exist"]):
        return "continuity_topology_nonconvergence"
    return "supporting_archive_only"


def extract_internal_dates(text: str) -> List[str]:
    """Extract date-like tokens from text."""
    out = []
    for pat in DATE_PATTERNS:
        out.extend(re.findall(pat, text))
    uniq = []
    seen = set()
    for item in out:
        item = item.strip()
        if item not in seen:
            uniq.append(item)
            seen.add(item)
    return uniq[:20]


def keyword_hits(text_l: str, rel_l: str) -> Dict[str, int]:
    """Count high-level keyword groups used by later stages."""
    material = rel_l + "\n" + text_l[:20000]
    result: Dict[str, int] = {}
    for tag, words in KEYWORDS.items():
        result[tag] = sum(material.count(w) for w in words)
    return result


def source_content_fingerprint(inventory: List[Dict[str, object]]) -> str:
    """Compute deterministic source fingerprint from relative path + file digest."""
    rows = [(str(r["path"]), str(r["sha256"])) for r in inventory]
    payload = json.dumps(sorted(rows), separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def main() -> None:
    """Run ingest stage and emit provenance-aligned manifests."""
    parser = argparse.ArgumentParser(description="Ingest governance archive into Hephaistos rebuild root.")
    add_common_args(parser)
    parser.add_argument(
        "--run-tag",
        default="",
        help="Optional run tag for traceability (ticket id, operator note, or date suffix).",
    )
    args = parser.parse_args()

    context = resolve_context(
        script_name="00_ingest_archive.py",
        build_root_arg=args.build_root,
        source_archive_arg=args.source_archive,
        run_id_arg=args.run_id,
        require_existing_context=False,
    )

    if not context.source_archive.exists():
        raise SystemExit(f"Source archive does not exist: {context.source_archive}")
    if not context.source_archive.is_dir():
        raise SystemExit(f"Source archive must be a directory: {context.source_archive}")

    manifests = context.manifests_dir
    processed = context.processed_dir
    logs = context.logs_dir
    text_dir = processed / "extracted_text"

    manifests.mkdir(parents=True, exist_ok=True)
    processed.mkdir(parents=True, exist_ok=True)
    logs.mkdir(parents=True, exist_ok=True)
    text_dir.mkdir(parents=True, exist_ok=True)

    write_build_context(context)

    files = sorted([p for p in context.source_archive.rglob("*") if p.is_file()])
    if not files:
        raise SystemExit(f"No files found under {context.source_archive}")

    inventory: List[Dict[str, object]] = []
    parse_errors = []
    ext_counter = Counter()
    hash_groups: Dict[str, List[str]] = defaultdict(list)

    extracted_index: Dict[str, Dict[str, object]] = {}
    seen_extracted_files: Dict[str, str] = {}

    for path in files:
        rel = normalize_rel_path(str(path.relative_to(context.source_archive)))
        stat = path.stat()
        ext = path.suffix.lower()
        ext_counter[ext or "<none>"] += 1

        digest = sha256_file(path)
        hash_groups[digest].append(rel)

        text = ""
        parse_status = "skipped_unparsed"
        if ext in PARSABLE_EXTS:
            text, parse_status = read_text(path)
        if parse_status.startswith("error") or parse_status.startswith("partial"):
            parse_errors.append({"path": rel, "parse_status": parse_status})

        extracted_meta = make_extracted_text_identity(rel)
        extracted_file_name = extracted_meta["file_name"]
        previous_rel = seen_extracted_files.get(extracted_file_name)
        if previous_rel and previous_rel != rel:
            raise SystemExit(
                "Extracted-text identity collision detected despite hash-based mapping: "
                f"{previous_rel} vs {rel} -> {extracted_file_name}"
            )
        seen_extracted_files[extracted_file_name] = rel

        extracted_output = text_dir / extracted_file_name
        if text:
            extracted_output.write_text(text, encoding="utf-8")

        extracted_index[rel] = {
            "relative_path": rel,
            "normalized_rel_path": extracted_meta["normalized_rel_path"],
            "extracted_text_id": extracted_meta["id"],
            "extracted_text_sha256": extracted_meta["hash_sha256"],
            "extracted_text_file": str(extracted_output.relative_to(context.build_root)),
            "text_present": bool(text),
            "parse_status": parse_status,
        }

        text_l = text.lower()
        function_role = guess_function(path, text_l)
        method_role = guess_method_role(rel, text_l)
        dates = extract_internal_dates(text)
        kw = keyword_hits(text_l, rel.lower())

        rec: Dict[str, object] = {
            "filename": path.name,
            "extension": ext,
            "path": rel,
            "size_bytes": stat.st_size,
            "created": datetime.fromtimestamp(stat.st_ctime, tz=timezone.utc).isoformat(),
            "modified": datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc).isoformat(),
            "sha256": digest,
            "parse_status": parse_status,
            "internal_dates": dates,
            "function_role_guess": function_role,
            "method_role_guess": method_role,
            "keyword_hits": kw,
            "text_excerpt": text[:1600],
            "line_count_est": text.count("\n") + 1 if text else 0,
            "word_count_est": len(re.findall(r"\S+", text)),
            "extracted_text_id": extracted_meta["id"],
            "extracted_text_file": str(extracted_output.relative_to(context.build_root)),
        }
        inventory.append(rec)

    duplicates = []
    for h, paths in hash_groups.items():
        if len(paths) > 1:
            duplicates.append({"sha256": h, "paths": paths, "count": len(paths)})

    write_json(manifests / "00_archive_inventory.json", inventory)
    write_json(manifests / "00_duplicate_hash_clusters.json", sorted(duplicates, key=lambda x: -x["count"]))
    write_json(logs / "00_parse_issues.json", parse_errors)
    write_json(context.build_root / EXTRACTED_TEXT_INDEX_PATH, extracted_index)

    csv_path = manifests / "00_archive_inventory.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(
            [
                "path",
                "extension",
                "size_bytes",
                "created",
                "modified",
                "sha256",
                "parse_status",
                "function_role_guess",
                "method_role_guess",
                "internal_dates",
                "word_count_est",
                "extracted_text_id",
                "extracted_text_file",
            ]
        )
        for r in inventory:
            writer.writerow(
                [
                    r["path"],
                    r["extension"],
                    r["size_bytes"],
                    r["created"],
                    r["modified"],
                    r["sha256"],
                    r["parse_status"],
                    r["function_role_guess"],
                    r["method_role_guess"],
                    "; ".join(r["internal_dates"]),
                    r["word_count_est"],
                    r["extracted_text_id"],
                    r["extracted_text_file"],
                ]
            )

    source_fingerprint = source_content_fingerprint(inventory)

    summary = {
        "schema_version": context.schema_version,
        "source_archive_path": str(context.source_archive),
        "source_archive_content_fingerprint": source_fingerprint,
        "build_root": str(context.build_root),
        "run_id": context.run_id,
        "config_fingerprint": context.config_fingerprint,
        "run_tag": args.run_tag or None,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "file_count": len(files),
        "extension_counts": dict(sorted(ext_counter.items())),
        "duplicate_hash_cluster_count": len(duplicates),
        "parse_issue_count": len(parse_errors),
        "extracted_text_index": str(EXTRACTED_TEXT_INDEX_PATH),
    }
    write_json(manifests / "00_archive_inventory_summary.json", summary)

    root_archive_manifest = {
        "schema_version": context.schema_version,
        "manifest_type": "archive_manifest_with_metadata",
        "source_archive_path": str(context.source_archive),
        "source_archive_content_fingerprint": source_fingerprint,
        "build_root": str(context.build_root),
        "run_id": context.run_id,
        "config_fingerprint": context.config_fingerprint,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "inventory_manifest": "DATA/MANIFESTS/00_archive_inventory.json",
        "inventory_summary_manifest": "DATA/MANIFESTS/00_archive_inventory_summary.json",
        "duplicate_hash_manifest": "DATA/MANIFESTS/00_duplicate_hash_clusters.json",
        "extracted_text_index_manifest": str(EXTRACTED_TEXT_INDEX_PATH),
        "file_count": len(files),
        "parse_issue_count": len(parse_errors),
    }
    write_json(
        context.root_logic_dir / "00_ROOT_ARCHIVE_MANIFEST_WITH_METADATA.json",
        root_archive_manifest,
    )

    stage_runtime_path = write_stage_runtime_config(
        context,
        stage_id="00_ingest",
        extra={
            "source_archive_content_fingerprint": source_fingerprint,
            "file_count": len(files),
            "parse_issue_count": len(parse_errors),
            "python_version": platform.python_version(),
        },
    )

    runtime_config = {
        "schema_version": context.schema_version,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "run_id": context.run_id,
        "run_tag": args.run_tag or None,
        "source_archive_path": str(context.source_archive),
        "source_archive_content_fingerprint": source_fingerprint,
        "build_root": str(context.build_root),
        "config_fingerprint": context.config_fingerprint,
        "runtime_context_manifest": str(stage_runtime_path.relative_to(context.build_root)),
        "cwd": str(Path.cwd()),
        "python_version": platform.python_version(),
    }
    write_json(logs / "00_ingest_runtime_config.json", runtime_config)

    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
