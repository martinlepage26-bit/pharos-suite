#!/usr/bin/env python3
"""Compatibility wrapper forwarding to 03_generate_required_docs.py."""
import runpy
from pathlib import Path

runpy.run_path(str(Path(__file__).with_name("03_generate_required_docs.py")), run_name="__main__")
