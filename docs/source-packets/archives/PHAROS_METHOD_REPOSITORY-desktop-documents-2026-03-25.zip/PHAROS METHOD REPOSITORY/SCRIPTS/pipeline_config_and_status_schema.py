#!/usr/bin/env python3
"""Shared Hephaistos pipeline governance config and status schema.

This module is the single source of truth for build context resolution,
canonical status enums, provenance metadata, and extracted-text identity.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

SCHEMA_VERSION = "hephaistos_pipeline_config_v1"

DEFAULT_SOURCE_ARCHIVE = Path("/mnt/c/Users/softinfo/Documents/MASTER PACK/MASTERxMASTERxMASTER")
DEFAULT_BUILD_ROOT = Path("/home/cerebrhoe/HEPHAISTOS_BUILD/MASTERxMASTERxMASTER_REBUILT")

ENV_SOURCE_ARCHIVE = "HEPHAISTOS_ARCHIVE_SOURCE"
ENV_BUILD_ROOT = "HEPHAISTOS_REBUILD_BASE"
ENV_RUN_ID = "HEPHAISTOS_RUN_ID"

BUILD_CONTEXT_PATH = Path("DATA/LOGS/00_build_context.json")
EXTRACTED_TEXT_INDEX_PATH = Path("DATA/PROCESSED/00_EXTRACTED_TEXT_INDEX.json")

CHECK_STATUS_PASS = "pass"
CHECK_STATUS_BOUNDED = "bounded"
CHECK_STATUS_FAIL = "fail"
CHECK_STATUSES = {CHECK_STATUS_PASS, CHECK_STATUS_BOUNDED, CHECK_STATUS_FAIL}

OVERALL_STATUS_READY_FULL = "ready_full"
OVERALL_STATUS_READY_WITH_BOUNDED_GAPS = "ready_with_bounded_gaps"
OVERALL_STATUS_NEEDS_REVISION_BEFORE_PROMOTION = "needs_revision_before_promotion"
OVERALL_STATUS_BLOCKED_NOT_READY = "blocked_not_ready"
OVERALL_STATUS_FAILED = "failed"
OVERALL_STATUS_INCOMPLETE = "incomplete"

OVERALL_STATUSES = {
    OVERALL_STATUS_READY_FULL,
    OVERALL_STATUS_READY_WITH_BOUNDED_GAPS,
    OVERALL_STATUS_NEEDS_REVISION_BEFORE_PROMOTION,
    OVERALL_STATUS_BLOCKED_NOT_READY,
    OVERALL_STATUS_FAILED,
    OVERALL_STATUS_INCOMPLETE,
}


def utc_now_iso() -> str:
    """Return current UTC timestamp in ISO 8601 format."""
    return datetime.now(timezone.utc).isoformat()


def normalize_path(value: str | Path) -> Path:
    """Normalize path into an absolute resolved Path."""
    return Path(value).expanduser().resolve()


def normalize_rel_path(rel_path: str) -> str:
    """Normalize relative paths for stable manifest and hashing behavior."""
    cleaned = rel_path.replace("\\", "/")
    while cleaned.startswith("./"):
        cleaned = cleaned[2:]
    return cleaned


@dataclass(frozen=True)
class BuildContext:
    """Canonical build context shared across all pipeline stages."""

    schema_version: str
    script_name: str
    build_root: Path
    source_archive: Path
    run_id: str
    generated_at_utc: str
    config_fingerprint: str
    context_source: str

    @property
    def manifests_dir(self) -> Path:
        return self.build_root / "DATA" / "MANIFESTS"

    @property
    def controls_dir(self) -> Path:
        return self.build_root / "DATA" / "CONTROLS"

    @property
    def processed_dir(self) -> Path:
        return self.build_root / "DATA" / "PROCESSED"

    @property
    def logs_dir(self) -> Path:
        return self.build_root / "DATA" / "LOGS"

    @property
    def vectors_dir(self) -> Path:
        return self.build_root / "DATA" / "VECTORS"

    @property
    def root_logic_dir(self) -> Path:
        return self.build_root / "00_ROOT_AND_ARCHIVE_LOGIC"

    @property
    def consolidated_dir(self) -> Path:
        return self.build_root / "90_CONSOLIDATED_FINAL_SYNTHESIS"

    def to_dict(self) -> Dict[str, Any]:
        """Serialize context as JSON-ready dictionary."""
        return {
            "schema_version": self.schema_version,
            "script_name": self.script_name,
            "build_root": str(self.build_root),
            "source_archive_path": str(self.source_archive),
            "run_id": self.run_id,
            "generated_at_utc": self.generated_at_utc,
            "config_fingerprint": self.config_fingerprint,
            "context_source": self.context_source,
            "status_schema": {
                "check_statuses": sorted(CHECK_STATUSES),
                "overall_statuses": sorted(OVERALL_STATUSES),
            },
            "env_overrides": {
                ENV_SOURCE_ARCHIVE: os.environ.get(ENV_SOURCE_ARCHIVE),
                ENV_BUILD_ROOT: os.environ.get(ENV_BUILD_ROOT),
                ENV_RUN_ID: os.environ.get(ENV_RUN_ID),
            },
        }


def add_common_args(
    parser: argparse.ArgumentParser,
    *,
    require_source_arg: bool = False,
    include_clean: bool = False,
) -> argparse.ArgumentParser:
    """Attach shared context args to script parsers."""
    parser.add_argument(
        "--build-root",
        default=None,
        help=f"Build output root. Defaults to env {ENV_BUILD_ROOT} or {DEFAULT_BUILD_ROOT}.",
    )
    parser.add_argument(
        "--source-archive",
        default=None,
        required=require_source_arg,
        help=f"Source archive root. Defaults to env {ENV_SOURCE_ARCHIVE}, context file, or {DEFAULT_SOURCE_ARCHIVE}.",
    )
    parser.add_argument(
        "--run-id",
        default=None,
        help=f"Optional run id. Defaults to env {ENV_RUN_ID}, context file, or UTC timestamp.",
    )
    if include_clean:
        parser.add_argument(
            "--clean",
            action="store_true",
            help="Clean generated outputs under build root before running pipeline.",
        )
    return parser


def _build_context_file(build_root: Path) -> Path:
    return build_root / BUILD_CONTEXT_PATH


def read_existing_context(build_root: Path) -> Optional[Dict[str, Any]]:
    """Read context file if present."""
    path = _build_context_file(build_root)
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def _compute_fingerprint(build_root: Path, source_archive: Path, run_id: str) -> str:
    payload = {
        "schema_version": SCHEMA_VERSION,
        "build_root": str(build_root),
        "source_archive_path": str(source_archive),
        "run_id": run_id,
        "status_schema": {
            "check_statuses": sorted(CHECK_STATUSES),
            "overall_statuses": sorted(OVERALL_STATUSES),
        },
    }
    blob = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def resolve_context(
    *,
    script_name: str,
    build_root_arg: Optional[str] = None,
    source_archive_arg: Optional[str] = None,
    run_id_arg: Optional[str] = None,
    require_existing_context: bool = False,
) -> BuildContext:
    """Resolve canonical context using args, env, and context file precedence.

    Precedence order:
    1) Explicit CLI arg
    2) Environment override
    3) Existing build context file
    4) Shared defaults (source/build root)
    """

    build_root_raw = build_root_arg or os.environ.get(ENV_BUILD_ROOT) or str(DEFAULT_BUILD_ROOT)
    build_root = normalize_path(build_root_raw)

    existing = read_existing_context(build_root)
    if require_existing_context and existing is None:
        raise SystemExit(
            f"{script_name}: missing required build context at {(_build_context_file(build_root)).as_posix()}. "
            "Run ingest first or pass explicit shared context arguments."
        )

    source_raw = (
        source_archive_arg
        or os.environ.get(ENV_SOURCE_ARCHIVE)
        or (existing or {}).get("source_archive_path")
        or str(DEFAULT_SOURCE_ARCHIVE)
    )
    source_archive = normalize_path(source_raw)

    run_id = run_id_arg or os.environ.get(ENV_RUN_ID) or (existing or {}).get("run_id") or utc_now_iso()

    context_source = "cli_or_env"
    if existing and not source_archive_arg and not os.environ.get(ENV_SOURCE_ARCHIVE):
        context_source = "existing_context"
    if not source_archive_arg and not os.environ.get(ENV_SOURCE_ARCHIVE) and not existing:
        context_source = "shared_default"

    fingerprint = _compute_fingerprint(build_root, source_archive, run_id)

    return BuildContext(
        schema_version=SCHEMA_VERSION,
        script_name=script_name,
        build_root=build_root,
        source_archive=source_archive,
        run_id=run_id,
        generated_at_utc=utc_now_iso(),
        config_fingerprint=fingerprint,
        context_source=context_source,
    )


def write_build_context(context: BuildContext) -> Path:
    """Write canonical context manifest for downstream stages."""
    path = _build_context_file(context.build_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(context.to_dict(), indent=2), encoding="utf-8")
    return path


def write_stage_runtime_config(
    context: BuildContext,
    *,
    stage_id: str,
    extra: Optional[Dict[str, Any]] = None,
) -> Path:
    """Write stage runtime config for cross-stage coherence validation."""
    payload = context.to_dict()
    payload["stage_id"] = stage_id
    if extra:
        payload["stage_extra"] = extra
    out_path = context.logs_dir / f"{stage_id}_runtime_config.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return out_path


def make_extracted_text_identity(rel_path: str) -> Dict[str, str]:
    """Return deterministic collision-safe extracted-text identity metadata."""
    normalized = normalize_rel_path(rel_path)
    digest = hashlib.sha256(normalized.encode("utf-8")).hexdigest()
    short = digest[:16]
    stem = Path(normalized).stem or "file"
    safe_stem = re.sub(r"[^A-Za-z0-9._-]+", "_", stem)[:48].strip("._") or "file"
    file_name = f"{safe_stem}__{short}.txt"
    return {
        "id": short,
        "normalized_rel_path": normalized,
        "hash_sha256": digest,
        "file_name": file_name,
    }


def read_json(path: Path, default: Any) -> Any:
    """Read JSON with default when file is missing."""
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: Any) -> None:
    """Write JSON with parent creation and pretty formatting."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def canonical_overall_status(status: str) -> str:
    """Validate and return canonical overall status enum."""
    if status not in OVERALL_STATUSES:
        raise ValueError(f"Unknown overall status `{status}`; expected one of {sorted(OVERALL_STATUSES)}")
    return status
