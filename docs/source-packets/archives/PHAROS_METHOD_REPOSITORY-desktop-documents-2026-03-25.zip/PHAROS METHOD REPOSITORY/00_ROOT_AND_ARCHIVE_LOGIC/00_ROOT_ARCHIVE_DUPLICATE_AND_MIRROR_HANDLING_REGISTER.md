# 00_ROOT_ARCHIVE_DUPLICATE_AND_MIRROR_HANDLING_REGISTER

## DUPCLUSTER_001_PHASE1_PASS_INSTRUCTIONS
- anchor: `DELIVEREX.txt`
- `DELIVEREX.txt` => original
- `EXPLAIN PHASE 1 PASS.txt` => cleaned_derivative

## DUPCLUSTER_002_GROK_PACKET_INTERPRETATIONS
- anchor: `GROK+AGATAH=======Dottie qwjo do yo.txt`
- `Grok INSERT MASTER PACK-AG.txt` => original
- `GROK+AGATAH=======Dottie qwjo do yo.txt` => revised

## DUPCLUSTER_003_AI_ANXIETY_MANUSCRIPT_LINEAGE
- anchor: `From AI Anxiety to Recursive Governance Under Constraint - AI and Society Manuscript.md`
- `ai-anxiety-recursive-governance-ai-society-aligned-2026-03-11.md` => original
- `From AI Anxiety to Recursive Governance Under Constraint - AI and Society Manuscript.md` => revised
- `PEER_REVIEW_READY_MANUSCRIPT_EXPANDED_300.md` => expanded

## DUPCLUSTER_004_PHAROS_PREVIEW_RECOVERY_NOTES
- anchor: `After reboot checklist.txt`
- `After reboot checklist.txt` => original
- `Here’s a one-page markdown version.txt` => cleaned_derivative
- `moving parts.txt` => compressed_derivative

## DUPCLUSTER_005_TRIANGULATION_SKILL_ALIAS
- anchor: `triangulation/SKILL.md`
- `triangulation/SKILL.md` => original
- `triangulate/SKILL.md` => redistributed_copy
