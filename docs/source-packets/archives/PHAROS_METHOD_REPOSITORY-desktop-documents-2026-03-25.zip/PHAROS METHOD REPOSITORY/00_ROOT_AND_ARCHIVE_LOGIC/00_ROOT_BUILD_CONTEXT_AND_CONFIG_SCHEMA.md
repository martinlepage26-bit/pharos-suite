# 00_ROOT_BUILD_CONTEXT_AND_CONFIG_SCHEMA
+
+Canonical build governance context for this run:
+
+- schema_version: `hephaistos_pipeline_config_v1`
+- build_root: `/home/cerebrhoe/HEPHAISTOS_BUILD/MASTERxMASTERxMASTER_REBUILT`
+- source_archive_path: `/mnt/c/Users/softinfo/Documents/MASTER PACK/MASTERxMASTERxMASTER`
+- run_id: `2026-03-24T14:33:19.048475+00:00`
+- config_fingerprint: `f5fa7fb1b4faae5dcb1238b1913d3888e8588877b6bcb708055398bc1a37365a`
+
+Canonical overall statuses:
+- blocked_not_ready
- failed
- incomplete
- needs_revision_before_promotion
- ready_full
- ready_with_bounded_gaps
+
+Canonical context source file:
+- `DATA/LOGS/00_build_context.json`
+
