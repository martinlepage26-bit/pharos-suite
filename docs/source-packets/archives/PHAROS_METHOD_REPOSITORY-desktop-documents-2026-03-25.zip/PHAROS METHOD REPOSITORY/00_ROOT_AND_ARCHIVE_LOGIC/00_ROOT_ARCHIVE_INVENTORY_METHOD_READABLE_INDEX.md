# 00_ROOT_ARCHIVE_INVENTORY_METHOD_READABLE_INDEX

- source_archive: `/mnt/c/Users/softinfo/Documents/MASTER PACK/MASTERxMASTERxMASTER`
- ingested_file_count: 116
- parse_coverage: full for parseable types; binary-only image kept as metadata artifact (`speech/assets/speech.png`)
- raw_mirror: `DATA/RAW/00_RAW_MASTERxMASTERxMASTER_SOURCE_MIRROR`
- primary_machine_owner: HEPHAISTOS local-first control

## Inventory Artifacts
- `DATA/MANIFESTS/00_archive_inventory.json`
- `DATA/MANIFESTS/00_archive_inventory.csv`
- `DATA/MANIFESTS/00_ARCHIVE_METADATA_MANIFEST.json`
- `DATA/MANIFESTS/00_ARCHIVE_METADATA_MANIFEST.csv`
- `DATA/MANIFESTS/00_FUNCTIONAL_CLASSIFICATION_MAP.json`
- `DATA/MANIFESTS/00_METHOD_ROLE_CLASSIFICATION_MAP.json`

## Delta-First Notes
- Exact duplicates by hash: none.
- Near-duplicate authority clusters: 5.
- Governance requirement: repeated or mirrored files retained as lineage evidence but de-ranked in authority.
