# 00_ROOT_ARCHIVE_MASTER_KEY_METHOD_AND_OBJECT_CLASSES

## Non-Negotiable Distinctions
- RECURSUS: bound corpus/archive packet.
- RECURSO: analytic phase processing that corpus.
- Laboratory != output.
- Governance containment != fabrication.
- Protocol closure != implementation surface.

## Object Classes (Operational)
- foundational signal conditions
- traversal protocols
- rupture events
- trigger structures
- recursive engines
- governance condensations
- legitimacy operators
- protocol thresholds
- amendment/key structures
- explanatory unlockers
- fabrication events
- output-control vectors
- continuity constraints
- reciprocal coupling operators
- topological stabilization forms
- skill distributions
- meta-governance files
- forge/build layers
- app implementation surfaces

## First/Second/Third Order Locks
- First order: Charge -> Witches' Road -> Glitch/Stutter -> Boobytrap.
- Second order: recursive pressure -> governance condensation -> v1 containment -> v2 intensification -> protocolization -> skill distribution -> forge/build.
- Third order: continuity, coupling, topology, bounded non-final governance.

## Bounded Claim Rule
When direct textual evidence for a required token is sparse or heterogeneously named, the boundary is degraded to bounded/degraded and not presented as exhaustive proof.
