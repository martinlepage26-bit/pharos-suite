# 00_ROOT_ARCHIVE_METADATA_MANIFEST_POINTER

Canonical metadata manifest files:
- `DATA/MANIFESTS/00_ARCHIVE_METADATA_MANIFEST.csv`
- `DATA/MANIFESTS/00_ARCHIVE_METADATA_MANIFEST.json`

These files are authoritative for per-file chronology, role classification, revision status, recursive role, and action decision.
