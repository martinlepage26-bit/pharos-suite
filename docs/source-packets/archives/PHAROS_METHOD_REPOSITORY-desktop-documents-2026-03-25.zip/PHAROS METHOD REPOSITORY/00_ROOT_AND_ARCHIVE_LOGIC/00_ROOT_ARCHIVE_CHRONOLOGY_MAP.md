# 00_ROOT_ARCHIVE_CHRONOLOGY_MAP

| idx | modified_utc | internal_primary_year | path |
|---:|---|---|---|
| 1 | 2026-01-19T06:05:42.021564+00:00 | 1978 | 2017 - Charging Objects Ritual, Artistic Practice, and the Crisis of Legitimacy.docx |
| 2 | 2026-02-14T14:51:00.734061+00:00 | - | SEALEDCARD.pdf |
| 3 | 2026-02-17T08:53:19.061574+00:00 | - | MARTIN voice specs.pdf |
| 4 | 2026-03-01T01:44:51.809030+00:00 | 2024 | THE VIOLET GEM (1).odt |
| 5 | 2026-03-01T02:18:14.362173+00:00 | - | Alambic.odt |
| 6 | 2026-03-07T09:03:34.703046+00:00 | 1935 | 2004 - Title The Sealed Card Protocol Mediated Legitimacy, Charging, and Governance at the Seam.docx |
| 7 | 2026-03-08T00:03:53+00:00 | 2004 | speech/LICENSE.txt |
| 8 | 2026-03-08T00:03:53+00:00 | 2025 | speech/SKILL.md |
| 9 | 2026-03-08T00:03:53+00:00 | - | speech/agents/openai.yaml |
| 10 | 2026-03-08T00:03:53+00:00 | 2000 | speech/assets/speech-small.svg |
| 11 | 2026-03-08T00:03:53+00:00 | - | speech/assets/speech.png |
| 12 | 2026-03-08T00:03:53+00:00 | - | speech/references/accessibility.md |
| 13 | 2026-03-08T00:03:53+00:00 | 2025 | speech/references/audio-api.md |
| 14 | 2026-03-08T00:03:53+00:00 | 2025 | speech/references/cli.md |
| 15 | 2026-03-08T00:03:53+00:00 | - | speech/references/codex-network.md |
| 16 | 2026-03-08T00:03:53+00:00 | - | speech/references/ivr.md |
| 17 | 2026-03-08T00:03:53+00:00 | - | speech/references/narration.md |
| 18 | 2026-03-08T00:03:53+00:00 | - | speech/references/prompting.md |
| 19 | 2026-03-08T00:03:53+00:00 | - | speech/references/sample-prompts.md |
| 20 | 2026-03-08T00:03:53+00:00 | - | speech/references/voice-directions.md |
| 21 | 2026-03-08T00:03:53+00:00 | - | speech/references/voiceover.md |
| 22 | 2026-03-08T00:03:53+00:00 | 2025 | speech/scripts/text_to_speech.py |
| 23 | 2026-03-09T17:23:34.496291+00:00 | 1919 | DELIVEREX.txt |
| 24 | 2026-03-09T17:24:22.323395+00:00 | 1919 | EXPLAIN PHASE 1 PASS.txt |
| 25 | 2026-03-09T19:55:33.762722+00:00 | - | SKILL ANALYZE.txt |
| 26 | 2026-03-09T20:10:03+00:00 | - | triangulation/scripts/triangulation.py |
| 27 | 2026-03-09T20:12:37+00:00 | - | triangulation/SKILL.md |
| 28 | 2026-03-09T20:12:37+00:00 | - | triangulation/agents/openai.yaml |
| 29 | 2026-03-09T21:36:04.236332+00:00 | - | CONSOLIDATED-PACK.txt |
| 30 | 2026-03-09T21:36:18.075183+00:00 | - | ETYMO.txt |
| 31 | 2026-03-09T22:52:50.688844+00:00 | - | CODEX FINAL TRUE.txt |
| 32 | 2026-03-10T04:51:53+00:00 | - | qualitative/agents/openai.yaml |
| 33 | 2026-03-10T04:54:18+00:00 | - | qualitative/SKILL.md |
| 34 | 2026-03-10T04:54:18+00:00 | - | qualitative/references/methods.md |
| 35 | 2026-03-10T06:00:27+00:00 | - | humanize/agents/openai.yaml |
| 36 | 2026-03-10T06:01:41.713421+00:00 | 1960 | Agathav4.1.docx |
| 37 | 2026-03-10T06:01:49+00:00 | - | humanize/SKILL.md |
| 38 | 2026-03-10T06:01:49+00:00 | - | humanize/references/culture.md |
| 39 | 2026-03-10T06:01:49+00:00 | - | humanize/references/diagnose.md |
| 40 | 2026-03-10T06:01:49+00:00 | - | humanize/references/redraft.md |
| 41 | 2026-03-10T07:32:15.071787+00:00 | 2017 | PEER_REVIEW_READY_MANUSCRIPT_EXPANDED_300.md |
| 42 | 2026-03-10T20:13:50.146563+00:00 | 2024 | MASTER ETHICS METHODS.odt |
| 43 | 2026-03-10T20:35:10+00:00 | - | triangulate/SKILL.md |
| 44 | 2026-03-10T20:35:10+00:00 | - | triangulate/agents/openai.yaml |
| 45 | 2026-03-10T20:35:10+00:00 | - | triangulate/scripts/triangulation.py |
| 46 | 2026-03-11T16:58:55+00:00 | - | peer-reviewed-paper-writer/agents/openai.yaml |
| 47 | 2026-03-11T17:03:10+00:00 | - | peer-reviewed-paper-writer/SKILL.md |
| 48 | 2026-03-11T17:03:10+00:00 | - | peer-reviewed-paper-writer/assets/reviewer-response-template.md |
| 49 | 2026-03-11T17:03:10+00:00 | - | peer-reviewed-paper-writer/references/manuscript-readiness-checklist.md |
| 50 | 2026-03-11T17:32:59.328363+00:00 | 2007 | ai-anxiety-recursive-governance-ai-society-aligned-2026-03-11.md |
| 51 | 2026-03-11T19:55:50+00:00 | - | recursive-governance-method/SKILL.md |
| 52 | 2026-03-11T19:55:50+00:00 | - | recursive-governance-method/references/example-prompts.md |
| 53 | 2026-03-11T19:55:50+00:00 | - | recursive-governance-method/references/method-rules.md |
| 54 | 2026-03-11T19:55:50+00:00 | - | recursive-governance-method/references/templates.md |
| 55 | 2026-03-11T19:55:50+00:00 | 2000 | recursive-governance-method/scripts/archive_triage.py |
| 56 | 2026-03-11T19:55:50+00:00 | - | recursive-governance-method/scripts/control_register.py |
| 57 | 2026-03-11T19:55:59+00:00 | - | recursive-governance-method/agents/openai.yaml |
| 58 | 2026-03-12T03:30:28+00:00 | - | brand-identity-system/SKILL.md |
| 59 | 2026-03-12T03:30:28+00:00 | - | brand-identity-system/agents/openai.yaml |
| 60 | 2026-03-12T03:30:28+00:00 | - | brand-identity-system/assets/color-palette-starter-kits/bold-tech.css |
| 61 | 2026-03-12T03:30:28+00:00 | - | brand-identity-system/assets/color-palette-starter-kits/friendly-approachable.css |
| 62 | 2026-03-12T03:30:28+00:00 | - | brand-identity-system/assets/color-palette-starter-kits/serious-trust.css |
| 63 | 2026-03-12T03:30:28+00:00 | - | brand-identity-system/assets/font-pairing-guides/classic-combos.md |
| 64 | 2026-03-12T03:30:28+00:00 | - | brand-identity-system/assets/font-pairing-guides/governance-appropriate.md |
| 65 | 2026-03-12T03:30:28+00:00 | - | brand-identity-system/assets/font-pairing-guides/modern-web.md |
| 66 | 2026-03-12T03:30:28+00:00 | - | brand-identity-system/examples/logo-critique.md |
| 67 | 2026-03-12T03:30:28+00:00 | - | brand-identity-system/examples/strong-identity-brief.md |
| 68 | 2026-03-12T03:30:28+00:00 | - | brand-identity-system/examples/weak-identity-brief.md |
| 69 | 2026-03-12T03:30:28+00:00 | - | brand-identity-system/examples/website-branding-direction.md |
| 70 | 2026-03-12T03:30:28+00:00 | - | brand-identity-system/references/diagnostic-protocol.md |
| 71 | 2026-03-12T03:30:28+00:00 | - | brand-identity-system/references/logo-protocol.md |
| 72 | 2026-03-12T03:30:28+00:00 | - | brand-identity-system/references/mini-style-guide-template.md |
| 73 | 2026-03-12T03:30:28+00:00 | - | brand-identity-system/references/output-contracts.md |
| 74 | 2026-03-12T03:30:28+00:00 | - | brand-identity-system/references/professional-services-branding.md |
| 75 | 2026-03-12T03:30:28+00:00 | - | brand-identity-system/references/strategic-brief-template.md |
| 76 | 2026-03-12T03:30:28+00:00 | - | brand-identity-system/references/website-protocol.md |
| 77 | 2026-03-12T07:37:21+00:00 | - | novelist/agents/openai.yaml |
| 78 | 2026-03-12T07:39:04+00:00 | - | novelist/references/novel-craft.md |
| 79 | 2026-03-12T07:39:31+00:00 | - | novelist/SKILL.md |
| 80 | 2026-03-12T07:46:33+00:00 | - | red-team/agents/openai.yaml |
| 81 | 2026-03-12T07:47:58+00:00 | - | red-team/SKILL.md |
| 82 | 2026-03-12T07:47:58+00:00 | - | red-team/references/red-team-reference.md |
| 83 | 2026-03-12T08:02:44+00:00 | - | skill-pairing/agents/openai.yaml |
| 84 | 2026-03-12T08:03:24+00:00 | - | skill-pairing/SKILL.md |
| 85 | 2026-03-12T12:31:05+00:00 | - | publisher/agents/openai.yaml |
| 86 | 2026-03-12T12:33:08+00:00 | - | publisher/SKILL.md |
| 87 | 2026-03-12T12:33:08+00:00 | - | publisher/references/role-map.md |
| 88 | 2026-03-13T00:23:01.454160+00:00 | - | Grok INSERT MASTER PACK-AG.txt |
| 89 | 2026-03-13T00:51:45.144065+00:00 | - | GROK+AGATAH=======Dottie qwjo do yo.txt |
| 90 | 2026-03-14T08:37:42.070017+00:00 | - | RDAIG_method_editorial_consolidation_2026-03-14.md |
| 91 | 2026-03-14T08:52:08.315963+00:00 | - | governance_storyboard.html |
| 92 | 2026-03-14T08:54:12.830282+00:00 | - | FINALTRUEMODEL-PURPLEBACK.HTML |
| 93 | 2026-03-14T10:00:56.391647+00:00 | - | RDAIG_governance_test_2026-03-14.md |
| 94 | 2026-03-14T10:04:36.202406+00:00 | - | rdaig_explainer.html |
| 95 | 2026-03-14T10:04:36.217998+00:00 | - | SCHOLARLY_PACKET_MANIFEST.md |
| 96 | 2026-03-14T10:15:36+00:00 | - | trace-investigator/agents/openai.yaml |
| 97 | 2026-03-14T10:16:04+00:00 | - | trace-investigator/SKILL.md |
| 98 | 2026-03-14T11:20:12+00:00 | - | fully-rounded-power-analyst/agents/openai.yaml |
| 99 | 2026-03-14T11:20:47+00:00 | - | fully-rounded-power-analyst/SKILL.md |
| 100 | 2026-03-14T11:43:19+00:00 | - | AI GOV CONSTITUTION.pdf |
| 101 | 2026-03-18T12:51:05.941179+00:00 | 2001 | “For Her Alone to Wield” The Infras.txt |
| 102 | 2026-03-19T22:31:11.719581+00:00 | 2013 | From AI Anxiety to Recursive Governance Under Constraint - AI and Society Manuscript.md |
| 103 | 2026-03-19T23:12:45.815211+00:00 | - | AI_Governance_Whos_the_Boob_Whos_the_Trap_40k_Target.md |
| 104 | 2026-03-21T10:22:47.127983+00:00 | - | Mobius-GPTExt-Think-Desktop-Super.txt |
| 105 | 2026-03-21T10:31:51.664545+00:00 | - | BOOB codex resume 019d067d-e829-700.txt |
| 106 | 2026-03-21T13:19:46.584770+00:00 | - | Mobius_Protocol_Template.txt |
| 107 | 2026-03-21T15:16:57.268533+00:00 | 1900 | A Master of Arts (MA) is a graduate.txt |
| 108 | 2026-03-22T14:31:00.560255+00:00 | - | After reboot checklist.txt |
| 109 | 2026-03-22T14:40:54.227604+00:00 | - | Here’s a one-page markdown version.txt |
| 110 | 2026-03-22T14:41:09.097582+00:00 | - | moving parts.txt |
| 111 | 2026-03-22T23:26:20.831295+00:00 | 1975 | discursive-authority-recursive-pressure-v2.docx.pdf |
| 112 | 2026-03-23T01:54:16.746005+00:00 | - | index.html |
| 113 | 2026-03-23T02:16:27.904811+00:00 | - | skill_ecosystem_tree.html |
| 114 | 2026-03-23T10:28:29.201592+00:00 | - | martin_lepage_governance_tree.html |
| 115 | 2026-03-23T12:50:06.117243+00:00 | - | heppaper.txt |
| 116 | 2026-03-23T12:52:51.505904+00:00 | - | This paper May NOT exist - DRAFTENDLOOP.txt |