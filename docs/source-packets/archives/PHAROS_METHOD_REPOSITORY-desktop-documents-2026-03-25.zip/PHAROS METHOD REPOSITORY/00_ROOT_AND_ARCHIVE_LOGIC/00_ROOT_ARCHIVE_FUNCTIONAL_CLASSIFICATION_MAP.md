# 00_ROOT_ARCHIVE_FUNCTIONAL_CLASSIFICATION_MAP

This file is the human-readable companion to `DATA/MANIFESTS/00_FUNCTIONAL_CLASSIFICATION_MAP.json`.

## Function Counts
- reference_note: 28
- note_or_working_artifact: 26
- skill_file: 14
- operator_or_skill_binding_config: 14
- manuscript_or_governance_document: 10
- manuscript_or_method_note: 8
- map_or_explainer_surface: 4
- build_or_method_script: 5

## Archive/Phase Distinction
- Corpus substrate and source-bearing documents are classified separately from phase outputs.
- Skills and references are classified as distribution/support artifacts, not primary corpus authority.
- Implementation notes are separated from governance containment artifacts.
