# 00_ROOT_ARCHIVE_PAPER_SORTING_AND_MERGER_DECISIONS

## Authority Clusters
- `DUPCLUSTER_001_PHASE1_PASS_INSTRUCTIONS` anchor=`DELIVEREX.txt` members=2
- `DUPCLUSTER_002_GROK_PACKET_INTERPRETATIONS` anchor=`GROK+AGATAH=======Dottie qwjo do yo.txt` members=2
- `DUPCLUSTER_003_AI_ANXIETY_MANUSCRIPT_LINEAGE` anchor=`From AI Anxiety to Recursive Governance Under Constraint - AI and Society Manuscript.md` members=3
- `DUPCLUSTER_004_PHAROS_PREVIEW_RECOVERY_NOTES` anchor=`After reboot checklist.txt` members=3
- `DUPCLUSTER_005_TRIANGULATION_SKILL_ALIAS` anchor=`triangulation/SKILL.md` members=2

## Paper-Line Decisions
- AI anxiety manuscript lineage:
  - anchor for consolidated paper base: `From AI Anxiety to Recursive Governance Under Constraint - AI and Society Manuscript.md`
  - supporting expanded branch: `PEER_REVIEW_READY_MANUSCRIPT_EXPANDED_300.md`
  - earlier aligned draft retained as lineage evidence: `ai-anxiety-recursive-governance-ai-society-aligned-2026-03-11.md`
- Phase-1 pass instructions:
  - anchor: `DELIVEREX.txt`
  - derivative merged: `EXPLAIN PHASE 1 PASS.txt`
- Grok interpretive packets:
  - anchor: `GROK+AGATAH=======Dottie qwjo do yo.txt`
  - earlier packet retained for audit trail: `Grok INSERT MASTER PACK-AG.txt`

## Preserve/Improve Law Applied
- preserve strong prose first
- improve weak/noisy artifacts second
- merge overlaps third
- generate only when missing structure required for method-readability
