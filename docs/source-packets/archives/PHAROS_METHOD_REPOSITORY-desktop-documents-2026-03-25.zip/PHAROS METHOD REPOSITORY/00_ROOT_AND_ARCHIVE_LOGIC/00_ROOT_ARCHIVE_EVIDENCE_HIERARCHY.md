# 00_ROOT_ARCHIVE_EVIDENCE_HIERARCHY

## distribution_artifact
- `speech/SKILL.md` | method_role=02_skill_distribution_layer | action=PRESERVE_AS_IS | confidence=medium
- `triangulation/SKILL.md` | method_role=02_skill_distribution_layer | action=PRESERVE_AS_IS | confidence=medium
- `qualitative/SKILL.md` | method_role=02_skill_distribution_layer | action=PRESERVE_AS_IS | confidence=medium
- `humanize/SKILL.md` | method_role=02_skill_distribution_layer | action=PRESERVE_AS_IS | confidence=medium
- `triangulate/SKILL.md` | method_role=02_skill_distribution_layer | action=PRESERVE_AS_IS | confidence=medium
- `peer-reviewed-paper-writer/SKILL.md` | method_role=02_skill_distribution_layer | action=PRESERVE_AS_IS | confidence=medium
- `recursive-governance-method/SKILL.md` | method_role=02_skill_distribution_layer | action=PRESERVE_AS_IS | confidence=medium
- `brand-identity-system/SKILL.md` | method_role=02_skill_distribution_layer | action=PRESERVE_AS_IS | confidence=medium
- `novelist/SKILL.md` | method_role=02_skill_distribution_layer | action=PRESERVE_AS_IS | confidence=medium
- `red-team/SKILL.md` | method_role=02_skill_distribution_layer | action=PRESERVE_AS_IS | confidence=medium
- `skill-pairing/SKILL.md` | method_role=02_skill_distribution_layer | action=PRESERVE_AS_IS | confidence=medium
- `publisher/SKILL.md` | method_role=02_skill_distribution_layer | action=PRESERVE_AS_IS | confidence=medium
- `trace-investigator/SKILL.md` | method_role=02_skill_distribution_layer | action=PRESERVE_AS_IS | confidence=medium
- `fully-rounded-power-analyst/SKILL.md` | method_role=02_skill_distribution_layer | action=PRESERVE_AS_IS | confidence=medium

## implementation_surface_evidence
- `BOOB codex resume 019d067d-e829-700.txt` | method_role=04_implementation_surface | action=DEPRECATED_BUT_RETAINED | confidence=high

## interpretive_or_generated_derivative
- `CODEX FINAL TRUE.txt` | method_role=00_or_supporting_archive_only | action=REVISE_AND_STRENGTHEN | confidence=bounded_low
- `Grok INSERT MASTER PACK-AG.txt` | method_role=00_or_supporting_archive_only | action=REVISE_AND_STRENGTHEN | confidence=bounded_low
- `GROK+AGATAH=======Dottie qwjo do yo.txt` | method_role=00_or_supporting_archive_only | action=REVISE_AND_STRENGTHEN | confidence=bounded_low
- `FINALTRUEMODEL-PURPLEBACK.HTML` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=bounded_low

## source_bearing_artifact
- `2017 - Charging Objects Ritual, Artistic Practice, and the Crisis of Legitimacy.docx` | method_role=01_epistemic_ignition_or_laboratory | action=PRESERVE_AND_LIGHTLY_CLEAN | confidence=high
- `SEALEDCARD.pdf` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=high
- `MARTIN voice specs.pdf` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=high
- `THE VIOLET GEM (1).odt` | method_role=01_phase_closure_protocol_layer | action=PRESERVE_AS_IS | confidence=high
- `Alambic.odt` | method_role=01_to_02_governance_containment_and_revision | action=PRESERVE_AS_IS | confidence=high
- `2004 - Title The Sealed Card Protocol Mediated Legitimacy, Charging, and Governance at the Seam.docx` | method_role=01_phase_closure_protocol_layer | action=PRESERVE_AND_LIGHTLY_CLEAN | confidence=high
- `Agathav4.1.docx` | method_role=01_epistemic_ignition_or_laboratory | action=PRESERVE_AND_LIGHTLY_CLEAN | confidence=high
- `PEER_REVIEW_READY_MANUSCRIPT_EXPANDED_300.md` | method_role=01_to_02_governance_containment_and_revision | action=PRESERVE_AND_LIGHTLY_CLEAN | confidence=high
- `MASTER ETHICS METHODS.odt` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=high
- `ai-anxiety-recursive-governance-ai-society-aligned-2026-03-11.md` | method_role=01_to_02_governance_containment_and_revision | action=MERGE_WITH_RELATED_FILE | confidence=high
- `RDAIG_method_editorial_consolidation_2026-03-14.md` | method_role=01_to_02_governance_containment_and_revision | action=PRESERVE_AS_IS | confidence=high
- `RDAIG_governance_test_2026-03-14.md` | method_role=01_to_02_governance_containment_and_revision | action=PRESERVE_AS_IS | confidence=high
- `SCHOLARLY_PACKET_MANIFEST.md` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=high
- `AI GOV CONSTITUTION.pdf` | method_role=01_to_02_governance_containment_and_revision | action=PRESERVE_AS_IS | confidence=high
- `From AI Anxiety to Recursive Governance Under Constraint - AI and Society Manuscript.md` | method_role=00_or_supporting_archive_only | action=PRESERVE_AND_LIGHTLY_CLEAN | confidence=high
- `AI_Governance_Whos_the_Boob_Whos_the_Trap_40k_Target.md` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=high
- `discursive-authority-recursive-pressure-v2.docx.pdf` | method_role=04_implementation_surface | action=PRESERVE_AND_LIGHTLY_CLEAN | confidence=high

## supporting_archive_artifact
- `speech/LICENSE.txt` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=bounded_low
- `speech/assets/speech-small.svg` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `speech/assets/speech.png` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `DELIVEREX.txt` | method_role=01_to_02_governance_containment_and_revision | action=PRESERVE_AS_IS | confidence=medium
- `EXPLAIN PHASE 1 PASS.txt` | method_role=01_to_02_governance_containment_and_revision | action=MERGE_WITH_RELATED_FILE | confidence=medium
- `SKILL ANALYZE.txt` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=bounded_low
- `CONSOLIDATED-PACK.txt` | method_role=00_or_supporting_archive_only | action=REVISE_AND_STRENGTHEN | confidence=bounded_low
- `ETYMO.txt` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=bounded_low
- `peer-reviewed-paper-writer/assets/reviewer-response-template.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `brand-identity-system/assets/color-palette-starter-kits/bold-tech.css` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `brand-identity-system/assets/color-palette-starter-kits/friendly-approachable.css` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `brand-identity-system/assets/color-palette-starter-kits/serious-trust.css` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `brand-identity-system/assets/font-pairing-guides/classic-combos.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `brand-identity-system/assets/font-pairing-guides/governance-appropriate.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `brand-identity-system/assets/font-pairing-guides/modern-web.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `brand-identity-system/examples/logo-critique.md` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=bounded_low
- `brand-identity-system/examples/strong-identity-brief.md` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=bounded_low
- `brand-identity-system/examples/weak-identity-brief.md` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=bounded_low
- `brand-identity-system/examples/website-branding-direction.md` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=bounded_low
- `governance_storyboard.html` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=bounded_low
- `rdaig_explainer.html` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=bounded_low
- `“For Her Alone to Wield” The Infras.txt` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=bounded_low
- `Mobius-GPTExt-Think-Desktop-Super.txt` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=bounded_low
- `Mobius_Protocol_Template.txt` | method_role=00_or_supporting_archive_only | action=REVISE_AND_STRENGTHEN | confidence=bounded_low
- `A Master of Arts (MA) is a graduate.txt` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=bounded_low
- `After reboot checklist.txt` | method_role=02_to_04_forge_build_implementation | action=PRESERVE_AS_IS | confidence=medium
- `Here’s a one-page markdown version.txt` | method_role=02_to_04_forge_build_implementation | action=MERGE_WITH_RELATED_FILE | confidence=medium
- `moving parts.txt` | method_role=02_to_04_forge_build_implementation | action=MERGE_WITH_RELATED_FILE | confidence=medium
- `index.html` | method_role=01_to_02_governance_containment_and_revision | action=PRESERVE_AS_IS | confidence=medium
- `skill_ecosystem_tree.html` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=bounded_low
- `martin_lepage_governance_tree.html` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=bounded_low
- `heppaper.txt` | method_role=02_to_04_forge_build_implementation | action=PRESERVE_AS_IS | confidence=medium
- `This paper May NOT exist - DRAFTENDLOOP.txt` | method_role=02_to_04_forge_build_implementation | action=DEPRECATED_BUT_RETAINED | confidence=medium

## supporting_implementation_artifact
- `speech/agents/openai.yaml` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `speech/references/accessibility.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `speech/references/audio-api.md` | method_role=04_implementation_surface | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `speech/references/cli.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `speech/references/codex-network.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `speech/references/ivr.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `speech/references/narration.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `speech/references/prompting.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `speech/references/sample-prompts.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `speech/references/voice-directions.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `speech/references/voiceover.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `speech/scripts/text_to_speech.py` | method_role=04_implementation_surface | action=PRESERVE_AND_LIGHTLY_CLEAN | confidence=bounded_low
- `triangulation/scripts/triangulation.py` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=bounded_low
- `triangulation/agents/openai.yaml` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `qualitative/agents/openai.yaml` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `qualitative/references/methods.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `humanize/agents/openai.yaml` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `humanize/references/culture.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `humanize/references/diagnose.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `humanize/references/redraft.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `triangulate/agents/openai.yaml` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `triangulate/scripts/triangulation.py` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=bounded_low
- `peer-reviewed-paper-writer/agents/openai.yaml` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `peer-reviewed-paper-writer/references/manuscript-readiness-checklist.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `recursive-governance-method/references/example-prompts.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `recursive-governance-method/references/method-rules.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `recursive-governance-method/references/templates.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `recursive-governance-method/scripts/archive_triage.py` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=bounded_low
- `recursive-governance-method/scripts/control_register.py` | method_role=00_or_supporting_archive_only | action=PRESERVE_AS_IS | confidence=bounded_low
- `recursive-governance-method/agents/openai.yaml` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `brand-identity-system/agents/openai.yaml` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `brand-identity-system/references/diagnostic-protocol.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `brand-identity-system/references/logo-protocol.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `brand-identity-system/references/mini-style-guide-template.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `brand-identity-system/references/output-contracts.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `brand-identity-system/references/professional-services-branding.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `brand-identity-system/references/strategic-brief-template.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `brand-identity-system/references/website-protocol.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `novelist/agents/openai.yaml` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `novelist/references/novel-craft.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `red-team/agents/openai.yaml` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `red-team/references/red-team-reference.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `skill-pairing/agents/openai.yaml` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `publisher/agents/openai.yaml` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `publisher/references/role-map.md` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `trace-investigator/agents/openai.yaml` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
- `fully-rounded-power-analyst/agents/openai.yaml` | method_role=00_or_supporting_archive_only | action=SUPPORTING_ARCHIVE_ONLY | confidence=bounded_low
