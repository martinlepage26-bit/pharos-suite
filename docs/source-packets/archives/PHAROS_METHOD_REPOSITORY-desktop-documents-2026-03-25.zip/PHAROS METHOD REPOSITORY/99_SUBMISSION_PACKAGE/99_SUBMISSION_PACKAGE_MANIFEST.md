# 99_SUBMISSION_PACKAGE_MANIFEST

Included for handoff:
- root logic and manifests
- phase packets 01/02/03/04
- consolidated synthesis 90
- controls and vectors
- scripts used to build and validate repository
