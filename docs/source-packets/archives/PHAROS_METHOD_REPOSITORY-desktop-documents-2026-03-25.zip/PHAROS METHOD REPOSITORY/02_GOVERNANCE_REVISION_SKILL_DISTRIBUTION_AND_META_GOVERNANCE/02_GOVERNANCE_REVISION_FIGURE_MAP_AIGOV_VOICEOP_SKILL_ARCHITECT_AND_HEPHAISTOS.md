# 02_GOVERNANCE_REVISION_FIGURE_MAP_AIGOV_VOICEOP_SKILL_ARCHITECT_AND_HEPHAISTOS

## Token Nodes
- `AIGOV1`: First Governance Containment
- `VOICEOP1`: First Voice Operator Layer
- `AIGOV2`: Recursive Governance Intensification
- `VOICEOP2`: Revised Voice Operator Layer
- `SKILL_DISTRIBUTION`: Distributed Skill Layer
- `SKILL_ARCHITECT`: Meta-Governance Skill Architecture
- `HEPHAISTOS_WSL`: Shared Forge Layer
- `CODEX_RUNTIME`: Codex Runtime
- `CLAUDE_RUNTIME`: Claude Runtime

## Lineage Edges
- `AIGOV1, VOICEOP1` -> `AIGOV2, VOICEOP2` (recursive_intensification)
- `AIGOV2, VOICEOP2` -> `SKILL_DISTRIBUTION` (distribution)
- `SKILL_DISTRIBUTION` -> `SKILL_ARCHITECT` (meta_governance_binding)
- `SKILL_ARCHITECT` -> `HEPHAISTOS_WSL` (forge_activation)
- `HEPHAISTOS_WSL` -> `CODEX_RUNTIME` (runtime_binding)
- `HEPHAISTOS_WSL` -> `CLAUDE_RUNTIME` (runtime_binding)
