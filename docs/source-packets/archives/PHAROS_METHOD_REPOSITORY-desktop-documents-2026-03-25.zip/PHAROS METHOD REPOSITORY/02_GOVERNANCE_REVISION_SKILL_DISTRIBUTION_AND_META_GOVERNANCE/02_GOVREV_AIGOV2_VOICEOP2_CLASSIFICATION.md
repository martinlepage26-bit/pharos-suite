# 02_GOVREV_AIGOV2_VOICEOP2_CLASSIFICATION

Archive evidence for revised containment is present across governance tests, editorial consolidations, and recursive revision notes.

Decision:
- canonicalize revision stage as `AIGOV2` + `VOICEOP2`.
- bind canonical tokens to archive evidence through manifest-backed stage mapping rather than filename rewriting.
