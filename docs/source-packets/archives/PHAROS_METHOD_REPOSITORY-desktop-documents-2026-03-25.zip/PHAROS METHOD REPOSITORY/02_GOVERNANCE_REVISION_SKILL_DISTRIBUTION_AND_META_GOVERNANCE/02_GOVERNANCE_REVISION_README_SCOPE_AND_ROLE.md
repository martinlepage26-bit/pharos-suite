# 02_GOVERNANCE_REVISION_README_SCOPE_AND_ROLE

Scope:
- make governance revision lineage explicit and validator-checkable
- make skill distribution and skill-architect meta-governance explicit
- bind Hephaistos as shared WSL forge across Codex and Claude runtimes

Role:
- architecture explicitness layer between source-bearing governance artifacts and downstream implementation synthesis
- machine-readable + method-readable anchor for revision lineage and token schema
