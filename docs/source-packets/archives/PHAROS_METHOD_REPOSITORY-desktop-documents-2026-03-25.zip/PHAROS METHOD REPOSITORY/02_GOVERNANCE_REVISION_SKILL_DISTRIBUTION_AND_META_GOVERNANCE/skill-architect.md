# skill-architect

Canonical meta-governance object for distributed skill architecture.

Contract:
- Distributed `SKILL.md` units are executable governance components.
- `skill-architect.md` governs routing, inheritance, constraint propagation, and conflict handling across those units.
- Hephaistos consumes this architecture in the shared WSL forge layer.

Lineage:
- AIGOV1 + VOICEOP1 -> AIGOV2 + VOICEOP2 -> SKILL_DISTRIBUTION -> SKILL_ARCHITECT -> HEPHAISTOS_WSL -> CODEX_RUNTIME + CLAUDE_RUNTIME.
