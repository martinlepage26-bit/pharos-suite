# 02_GOVREV_SKILL_DISTRIBUTION_MAP

Distributed skill units are present as modular governance carriers.

| path | revision_status | action | evidence_status |
|---|---|---|---|
| `brand-identity-system/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS | distribution_artifact |
| `fully-rounded-power-analyst/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS | distribution_artifact |
| `humanize/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS | distribution_artifact |
| `novelist/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS | distribution_artifact |
| `peer-reviewed-paper-writer/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS | distribution_artifact |
| `publisher/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS | distribution_artifact |
| `qualitative/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS | distribution_artifact |
| `recursive-governance-method/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS | distribution_artifact |
| `red-team/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS | distribution_artifact |
| `skill-pairing/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS | distribution_artifact |
| `speech/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS | distribution_artifact |
| `trace-investigator/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS | distribution_artifact |
| `triangulate/SKILL.md` | redistributed_copy | PRESERVE_AS_IS | distribution_artifact |
| `triangulation/SKILL.md` | original | PRESERVE_AS_IS | distribution_artifact |
