# 02_GOVREV_GOVERNANCE_REVISION_LINEAGE

Observed revision route:
- constitution and method notes establish initial containment grammar
- governance tests and editorial consolidations tighten claim boundaries
- manuscript revisions absorb governance constraints
- distributed skills externalize constrained method units

This is revision through recursion, not simple version bumping.
