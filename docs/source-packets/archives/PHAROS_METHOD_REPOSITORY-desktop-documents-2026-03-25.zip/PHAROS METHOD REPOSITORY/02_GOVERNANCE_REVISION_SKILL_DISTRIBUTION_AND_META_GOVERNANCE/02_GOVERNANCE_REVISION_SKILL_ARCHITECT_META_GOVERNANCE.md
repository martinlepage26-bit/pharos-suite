# 02_GOVERNANCE_REVISION_SKILL_ARCHITECT_META_GOVERNANCE

Canonical statement:
- `skill-architect.md` is the governing meta-architecture object for distributed `SKILL.md` units.

Governance function:
- route skill invocation and inheritance constraints
- define conflict-handling order between skill units
- bind distributed skills to shared Hephaistos forge governance

Operational relation:
- `skill-architect.md` governs distribution semantics; `HEPHAISTOS_WSL` executes under that governance.
