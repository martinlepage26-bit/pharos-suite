# 02_GOVREV_SKILL_FILE_INVENTORY

| idx | path | revision_status | action |
|---:|---|---|---|
| 1 | `brand-identity-system/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS |
| 2 | `fully-rounded-power-analyst/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS |
| 3 | `humanize/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS |
| 4 | `novelist/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS |
| 5 | `peer-reviewed-paper-writer/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS |
| 6 | `publisher/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS |
| 7 | `qualitative/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS |
| 8 | `recursive-governance-method/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS |
| 9 | `red-team/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS |
| 10 | `skill-pairing/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS |
| 11 | `speech/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS |
| 12 | `trace-investigator/SKILL.md` | distributed_snapshot | PRESERVE_AS_IS |
| 13 | `triangulate/SKILL.md` | redistributed_copy | PRESERVE_AS_IS |
| 14 | `triangulation/SKILL.md` | original | PRESERVE_AS_IS |
