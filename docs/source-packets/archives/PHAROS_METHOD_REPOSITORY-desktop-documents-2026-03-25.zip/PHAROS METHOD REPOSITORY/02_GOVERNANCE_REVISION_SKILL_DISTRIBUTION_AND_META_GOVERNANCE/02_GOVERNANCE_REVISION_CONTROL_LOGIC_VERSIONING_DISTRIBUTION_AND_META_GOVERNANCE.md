# 02_GOVERNANCE_REVISION_CONTROL_LOGIC_VERSIONING_DISTRIBUTION_AND_META_GOVERNANCE

Control logic:
- stage versioning is explicit (`AIGOV1/VOICEOP1` then `AIGOV2/VOICEOP2`)
- distributed skill units are governed by explicit meta-layer (`skill-architect.md`)
- forge/build execution authority is constrained to shared `HEPHAISTOS_WSL` governance
- runtime implementations (`CODEX_RUNTIME`, `CLAUDE_RUNTIME`) inherit shared forge controls

Validator-facing expectation:
- missing any stage mapping fails architecture-explicitness validation.
