# 02_GOVREV_NOTE_AIGOV2_VOICEOP2_EQUIVALENCE

Operator interpretive note (2026-03-24):
- `AIGOV2` and `VOICEOP2` are canonical architecture tokens for revised containment logic in this rebuild.
- source files keep original names; stage assignment is recorded in the governance-revision manifest.

Usage rule:
- keep this as a governance interpretation note.
- do not rewrite source-file names or force synthetic token substitutions in raw evidence manifests.
