# 00_CONTROL_PHASE_TEST_RESULTS

## 01_IGNITION_TEST
- status: supported
- terms_with_hits: 3 / 3
- term `ignition_witches_road` => files_with_hits=5
  - `Agathav4.1.docx` (2)
  - `THE VIOLET GEM (1).odt` (2)
  - `heppaper.txt` (4)
- term `ignition_agatha_all_along` => files_with_hits=3
  - `2004 - Title The Sealed Card Protocol Mediated Legitimacy, Charging, and Governance at the Seam.docx` (3)
  - `Agathav4.1.docx` (5)
  - `index.html` (2)
- term `first_order_charge` => files_with_hits=10
  - `2004 - Title The Sealed Card Protocol Mediated Legitimacy, Charging, and Governance at the Seam.docx` (27)
  - `2017 - Charging Objects Ritual, Artistic Practice, and the Crisis of Legitimacy.docx` (100)
  - `Agathav4.1.docx` (4)

## 02_LABORATORY_TEST
- status: supported
- terms_with_hits: 2 / 2
- term `lab_hexa` => files_with_hits=3
  - `2004 - Title The Sealed Card Protocol Mediated Legitimacy, Charging, and Governance at the Seam.docx` (3)
  - `Alambic.odt` (1)
  - `THE VIOLET GEM (1).odt` (16)
- term `lab_wheels_of_will` => files_with_hits=3
  - `2004 - Title The Sealed Card Protocol Mediated Legitimacy, Charging, and Governance at the Seam.docx` (4)
  - `2017 - Charging Objects Ritual, Artistic Practice, and the Crisis of Legitimacy.docx` (34)
  - `Alambic.odt` (4)

## 03_CORPUS_TEST
- status: supported
- terms_with_hits: 3 / 3
- term `buffy` => files_with_hits=5
  - `2004 - Title The Sealed Card Protocol Mediated Legitimacy, Charging, and Governance at the Seam.docx` (3)
  - `Agathav4.1.docx` (1)
  - `THE VIOLET GEM (1).odt` (7)
- term `buffy_for_her_alone_to_wield` => files_with_hits=1
  - `“For Her Alone to Wield” The Infras.txt` (1)
- term `corpus_discursive_authority` => files_with_hits=2
  - `index.html` (7)
  - `martin_lepage_governance_tree.html` (2)

## 04_GOVERNANCE_CONTAINMENT_TEST
- status: partially_supported_bounded
- terms_with_hits: 1 / 3
- term `gov_aigov1` => files_with_hits=0
- term `gov_voice_operator1` => files_with_hits=0
- term `protocol_sealed_card` => files_with_hits=3
  - `2004 - Title The Sealed Card Protocol Mediated Legitimacy, Charging, and Governance at the Seam.docx` (12)
  - `THE VIOLET GEM (1).odt` (6)
  - `index.html` (3)

## 05_RECURSIVE_FEEDBACK_TEST
- status: supported
- terms_with_hits: 3 / 3
- term `recurso` => files_with_hits=9
  - `CODEX FINAL TRUE.txt` (6)
  - `DELIVEREX.txt` (5)
  - `EXPLAIN PHASE 1 PASS.txt` (5)
- term `recursus` => files_with_hits=4
  - `ETYMO.txt` (1)
  - `FINALTRUEMODEL-PURPLEBACK.HTML` (1)
  - `GROK+AGATAH=======Dottie qwjo do yo.txt` (1)
- term `first_order_glitch` => files_with_hits=11
  - `2004 - Title The Sealed Card Protocol Mediated Legitimacy, Charging, and Governance at the Seam.docx` (22)
  - `AI GOV CONSTITUTION.pdf` (3)
  - `AI_Governance_Whos_the_Boob_Whos_the_Trap_40k_Target.md` (2)

## 06_CLOSURE_TEST
- status: supported
- terms_with_hits: 1 / 1
- term `protocol_sealed_card` => files_with_hits=3
  - `2004 - Title The Sealed Card Protocol Mediated Legitimacy, Charging, and Governance at the Seam.docx` (12)
  - `THE VIOLET GEM (1).odt` (6)
  - `index.html` (3)

## 07_CARRIAGE_KEY_EXPLAINER_TEST
- status: supported
- terms_with_hits: 3 / 3
- term `protocol_violet_gem` => files_with_hits=2
  - `Alambic.odt` (4)
  - `index.html` (3)
- term `protocol_alambic` => files_with_hits=2
  - `index.html` (4)
  - `martin_lepage_governance_tree.html` (4)
- term `protocol_master_key` => files_with_hits=1
  - `CODEX FINAL TRUE.txt` (1)

## 08_GOVERNANCE_REVISION_TEST
- status: not_supported_in_archive
- terms_with_hits: 0 / 3
- term `gov_aigov2` => files_with_hits=0
- term `gov_voice_operator2` => files_with_hits=0
- term `gov_aigov1` => files_with_hits=0

## 09_SKILL_DISTRIBUTION_TEST
- status: supported
- terms_with_hits: 1 / 1
- term `distribution_skill_md` => files_with_hits=6
  - `SKILL ANALYZE.txt` (13)
  - `index.html` (3)
  - `martin_lepage_governance_tree.html` (2)

## 10_MASTER_GOVERNANCE_TEST
- status: not_supported_in_archive
- terms_with_hits: 0 / 1
- term `distribution_masterskill` => files_with_hits=0

## 11_HEPHAISTOS_TEST
- status: supported
- terms_with_hits: 2 / 2
- term `forge_hephaistos` => files_with_hits=2
  - `This paper May NOT exist - DRAFTENDLOOP.txt` (1)
  - `heppaper.txt` (59)
- term `forge_wsl` => files_with_hits=2
  - `After reboot checklist.txt` (3)
  - `Here’s a one-page markdown version.txt` (1)

## 12_BUFFY_CLUSTER_TEST
- status: partially_supported_bounded
- terms_with_hits: 2 / 3
- term `buffy` => files_with_hits=5
  - `2004 - Title The Sealed Card Protocol Mediated Legitimacy, Charging, and Governance at the Seam.docx` (3)
  - `Agathav4.1.docx` (1)
  - `THE VIOLET GEM (1).odt` (7)
- term `buffy_for_her_alone_to_wield` => files_with_hits=1
  - `“For Her Alone to Wield” The Infras.txt` (1)
- term `buffy_hair_as_battle_scar` => files_with_hits=0

## 13_IMPLEMENTATION_SURFACE_TEST
- status: partially_supported_bounded
- terms_with_hits: 5 / 7
- term `impl_lotus` => files_with_hits=0
- term `impl_echo` => files_with_hits=7
  - `2004 - Title The Sealed Card Protocol Mediated Legitimacy, Charging, and Governance at the Seam.docx` (3)
  - `MARTIN voice specs.pdf` (1)
  - `Mobius-GPTExt-Think-Desktop-Super.txt` (2)
- term `impl_scriptorium` => files_with_hits=1
  - `THE VIOLET GEM (1).odt` (6)
- term `impl_dr_sort` => files_with_hits=0
- term `impl_compassai` => files_with_hits=3
  - `After reboot checklist.txt` (1)
  - `Here’s a one-page markdown version.txt` (1)
  - `moving parts.txt` (1)
- term `impl_aurorai` => files_with_hits=3
  - `After reboot checklist.txt` (2)
  - `Here’s a one-page markdown version.txt` (2)
  - `moving parts.txt` (1)
- term `impl_pharos_govern_ai` => files_with_hits=9
  - `2004 - Title The Sealed Card Protocol Mediated Legitimacy, Charging, and Governance at the Seam.docx` (1)
  - `After reboot checklist.txt` (22)
  - `BOOB codex resume 019d067d-e829-700.txt` (1)

## 14_ARCHIVE_PHASE_DISTINCTION_TEST
- status: supported
- terms_with_hits: 3 / 3
- term `recurso` => files_with_hits=9
  - `CODEX FINAL TRUE.txt` (6)
  - `DELIVEREX.txt` (5)
  - `EXPLAIN PHASE 1 PASS.txt` (5)
- term `recursus` => files_with_hits=4
  - `ETYMO.txt` (1)
  - `FINALTRUEMODEL-PURPLEBACK.HTML` (1)
  - `GROK+AGATAH=======Dottie qwjo do yo.txt` (1)
- term `distribution_skill_md` => files_with_hits=6
  - `SKILL ANALYZE.txt` (13)
  - `index.html` (3)
  - `martin_lepage_governance_tree.html` (2)
