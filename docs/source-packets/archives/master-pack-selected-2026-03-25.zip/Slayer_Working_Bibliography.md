# Slayer Recursion Paper: Working Bibliography

This file preserves the bibliography material supplied in the working session and separates entries that appear verified from entries that still need edition or publication-detail checks before submission.

## Core Theory Cluster

Ahmed, Sara. *The Promise of Happiness*. Durham, NC: Duke University Press, 2010.

Ahmed, Sara. *Queer Phenomenology: Orientations, Objects, Others*. Durham, NC: Duke University Press, 2006.

Banet-Weiser, Sarah. *Authentic™: The Politics of Ambivalence in a Brand Culture*. New York: New York University Press, 2012.

Banet-Weiser, Sarah. *Kids Rule!: Nickelodeon and Consumer Citizenship*. Durham, NC: Duke University Press, 2007.

Berlant, Lauren. *Cruel Optimism*. Durham, NC: Duke University Press, 2011.

Bordo, Susan. *Unbearable Weight: Feminism, Western Culture, and the Body*. Berkeley: University of California Press, 1993.

Braidotti, Rosi. *The Posthuman*. Cambridge: Polity Press, 2013.

Halberstam, Jack. *The Queer Art of Failure*. Durham, NC: Duke University Press, 2011.

Haraway, Donna J. *Simians, Cyborgs, and Women: The Reinvention of Nature*. New York: Routledge, 1991.

hooks, bell. *Feminist Theory: From Margin to Center*. Boston: South End Press, 1984.

Jenkins, Henry. *Textual Poachers: Television Fans and Participatory Culture*. New York: Routledge, 1992.

McRobbie, Angela. *The Aftermath of Feminism: Gender, Culture and Social Change*. London: SAGE Publications, 2009.

Mittell, Jason. *Complex TV: The Poetics of Contemporary Television Storytelling*. New York: New York University Press, 2015.

Muñoz, José Esteban. *Cruising Utopia: The Then and There of Queer Futurity*. New York: New York University Press, 2009.

Russell, Legacy. *Glitch Feminism: A Manifesto*. London: Verso Books, 2020.

Taylor, Diana. *The Archive and the Repertoire: Performing Cultural Memory in the Americas*. Durham, NC: Duke University Press, 2003.

## Buffy-Specific and Paratextual Materials Mentioned in Working Notes

Allie, Scott. Interview with the creative team, in *Buffy the Vampire Slayer: Season Ten—New Rules Deluxe Edition*.

Gage, Christos, et al. "New Rules." *Buffy the Vampire Slayer Season Ten*, vol. 1.

Jeanty, Georges. Artist interview, in *Buffy the Vampire Slayer: Season Eight—The Long Way Home Deluxe Edition*.

Ruditis, Paul. *Buffy the Vampire Slayer: The Watcher's Guide*, vol. 3.

Stafford, Nikki. *Bite Me!: The Unofficial Guide to Buffy the Vampire Slayer*.

Whedon, Joss, et al. "The Long Way Home." *Buffy the Vampire Slayer Season Eight*, vol. 1.

Whedon, Joss, et al. "Freefall." *Buffy the Vampire Slayer: Season Nine*, vol. 1.

## Additional Primary Buffy Episode References Mentioned in Working Notes

- "Welcome to the Hellmouth"
- "Prophecy Girl"
- "Becoming, Part One"
- "Becoming, Part Two"
- "Graduation Day, Part One"
- "Graduation Day, Part Two"
- "The Freshman"
- "Restless"
- "Buffy vs. Dracula"
- "Fool for Love"
- "The Gift"
- "Bargaining, Part One"
- "Bargaining, Part Two"
- "Gone"
- "Lessons"
- "Showtime"
- "Chosen"

## Entries Flagged in Session as Still Needing Verification

- Ang, Ien. *Living Room Wars*
- Brunsdon, Charlotte. *The Feminist, the Housewife, and the Soap Opera*
- Bruzzi, Stella. *Undressing Cinema*
- Dyer, Richard. *Stars*
- Gill, Rosalind. *Gender and the Media*
- Lotz, Amanda D. *Redesigning Women*
- Tasker, Yvonne. *Working Girls*
- Tasker, Yvonne, and Diane Negra, eds. *Interrogating Postfeminism*
- Williams, Rebecca. *Post-Object Fandom*

## Working Caution

Some quotations discussed in session came from secondary quote sites, reviews, or partial previews rather than directly from the books. Before submission, verify all page-numbered quotations against the actual editions being cited.
