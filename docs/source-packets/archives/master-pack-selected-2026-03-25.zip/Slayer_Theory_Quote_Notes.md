# Sourced Quotes for "The Slayer Recursion" Paper

This file preserves the working theory-quote packet supplied during drafting.

Important:
- These notes are useful for chapter-to-theory alignment.
- Several attributions came from quote sites, previews, reviews, or tertiary webpages rather than directly from the books.
- Before submission, verify every direct quotation and page number against the actual edition being cited.

## Chapter I — The Proprietary Root / Shadow Men as Closed Source (v1.0)

### Sara Ahmed, *Queer Phenomenology* (2006)

Working use:
- Ahmed's framework of orientation maps onto the Shadow Men's attempt to line the Slayer's body up with a prescribed function.

Working quotation notes:
- Bodies are shaped in forms that "enable some action only insofar as they restrict the capacity for other kinds of action" (reported as p. 91 in working notes).
- Working note also connected Ahmed's account of orientation and inhabiting space to the violence of prescribed lines.
- A separate working note linked Ahmed to disorientation as a productive reordering of social relations.

Status:
- Use conceptually in the draft now.
- Recheck page numbers and wording in the book before final citation.

### Lauren Berlant, *Cruel Optimism* (2011)

Working use:
- The Slayer/Watcher structure can be read as an attachment that promises meaning and protection while undermining the one who must inhabit it.

Working quotation note:
- "A relation of cruel optimism exists when something you desire is actually an obstacle to your flourishing."

Status:
- Widely cited formulation and safe to paraphrase now.
- Final direct quotation should still be checked in the edition used.

## Chapter II — The --yolo Event / "Chosen" as Open Source Release (v2.0)

### José Esteban Muñoz, *Cruising Utopia* (2009)

Working use:
- Willow's spell can be read through Muñoz's concrete utopia and queer futurity as a collective break with the inherited present.

Working quotation notes:
- "Queerness is not yet here. Queerness is an ideality."
- "Concrete utopias are relational to historically situated struggles..."
- "Concrete utopias are the realm of educated hope."

Status:
- Strong conceptual fit for the chapter.
- Verify all wording and page numbers in the book before using as formal quotations.

### Legacy Russell, *Glitch Feminism* (2020)

Working use:
- "Chosen" can be read as a deliberate system failure that breaks the old code of singular Slayer legitimacy.

Working quotation notes:
- "As glitch feminists, this is our politic: we refuse to be hewn to the hegemonic line of a binary body. This calculated failure prompts the violent socio-cultural machine to hiccup, sigh, shudder, buffer."
- Working notes also linked Russell's account of survival and system failure to the newly activated Slayers.

Status:
- A publicly accessible PDF excerpt was available during drafting, but page numbers should still be checked against the edition used for submission.

## Chapter III — The Legacy System & Data Corruption / Melaka Fray (v3.0)

### Diana Taylor, *The Archive and the Repertoire* (2003)

Working use:
- Melaka's severed prophetic dream chain can be read as a failure of embodied transfer and living continuity.

Working quotation notes:
- Archive versus repertoire was summarized as the difference between enduring materials and embodied practice or knowledge.
- Working note: performance as a "vital act of transfer" transmitting social knowledge, cultural memory, and identities.

Status:
- Core conceptual fit is strong.
- Verify exact wording, punctuation, and page references before formal citation.

### Rosi Braidotti, *The Posthuman* (2013)

Working use:
- Melaka can be read as a subject navigating fragmented continuity, while Harth represents knowledge severed from ethical accountability.

Working quotation notes:
- Working notes connected Braidotti's discussion of critical distance, dis-identification, and ethical posthuman subjectivity to the *Fray* world.

Status:
- Use as a conceptual frame now.
- Confirm the exact quotations against the book before finalizing.

## Chapter IV — The Multi-Platform Sync / Buffy Meets Melaka

### Ahmed on disorientation

Working use:
- Buffy and Melaka's encounter can be framed as a productive disorientation that reorders what each can perceive about her own historical position.

Status:
- Keep as conceptual language unless the exact quotation is verified from Ahmed directly.

### Muñoz on the no-longer-conscious and the not-yet-here

Working use:
- Buffy and Melaka can be framed as a temporal collision between a prior struggle and an unfinished future.

Status:
- Strong conceptual fit.
- Verify exact wording before using as a direct quotation.

## Cross-Cutting — Ubuntu / Collective Attachment

### Berlant

Working use:
- Collective attachment can be used to think about the Slayer line as a relational structure rather than just individual destiny.

Status:
- Verify exact wording if quoted directly.

### Russell

Working use:
- Russell's language of collective and digitally mediated selves can help describe the post-"Chosen" Slayer network as distributed rather than singular.

Status:
- Useful conceptually.
- Check all direct quotations against the edition used in final drafting.
